// studio/src/app/studio/[projectId]/editor/page.tsx

import EditorClient from '@/components/gnapex-studio/editor-client';

export default function EditorPage({
  params,
}: {
  params: Promise<{ projectId: string }>;
}) {
  return <EditorClient params={params} />;
}
