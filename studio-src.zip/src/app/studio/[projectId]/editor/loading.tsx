// studio/src/app/studio/[projectId]/editor/loading.tsx
//
// Route-level boot screen while the editor's data is assembling.

export default function EditorLoading() {
  return (
    <div className="flex h-dvh flex-col items-center justify-center gap-3 bg-[#090A0F]">
      <div className="size-7 animate-spin rounded-full border-2 border-[#00D4FF] border-t-transparent" />
      <p className="text-[11px] font-mono uppercase tracking-widest text-gray-500">
        Opening GN-Apex Studio
      </p>
    </div>
  );
}
