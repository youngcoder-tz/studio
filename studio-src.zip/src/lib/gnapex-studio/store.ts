// studio/src/lib/gnapex-studio/store.ts
//
// THE EDITOR STATE STORE.
//
// Zustand for editor UI state (selection, viewport, bridge status, staged
// edits) — server state stays in TanStack Query. This split is deliberate:
// the document's canonical copy is whatever the backend accepted last, and
// `document` here is an optimistic mirror that autosave reconciles.
//
// All structural edits flow through typed `WorkspaceOperation`s staged into
// `pendingOps`; the autosave hook owns when they hit the API. Selection is
// scoped (`workspace` | `page` | `component`) and drives the whole shell.

import { create } from 'zustand';
import type {
  WorkspaceDocument,
  WorkspaceOperation,
} from '../contract';
import type {
  EditorSelection,
  ViewportKey,
} from './types';
import type { StudioNodeBounds } from './bridge-protocol';

export type BridgeStatus = 'connecting' | 'active' | 'unavailable';
export type ExplorerTab = 'structure' | 'layers';

export interface EditorMeta {
  projectId: string;
  projectName: string;
  workspaceMode: string;
}

interface EditorStore {
  // ── boot data ──
  meta: EditorMeta | null;
  document: WorkspaceDocument | null;

  // ── selection & canvas ──
  selection: EditorSelection;
  hoverInstanceId: string | null;
  viewport: ViewportKey;
  bridgeStatus: BridgeStatus;
  bridgeError: string | null;
  /** Page key the preview frame self-reports (reconciled with selection). */
  previewPageKey: string | null;
  /** Bounds cache by instanceId — populated only through the bridge. */
  bounds: Record<string, StudioNodeBounds>;
  /** Preview frame nonce — bumping it remounts the iframe. */
  frameNonce: number;

  // ── panels ──
  explorerTab: ExplorerTab;

  // ── edits ──
  /** Staged, unsaved operations in arrival order. */
  pendingOps: WorkspaceOperation[];
  /** Serialized timestamp of the last successful autosave. */
  lastSavedAt: number | null;
  saveError: string | null;

  // ── actions ──
  setMeta: (meta: EditorMeta) => void;
  hydrateDocument: (document: WorkspaceDocument) => void;
  adoptServerDocument: (document: WorkspaceDocument, savedAt: number) => void;

  selectWorkspace: () => void;
  selectPage: (pageKey: string) => void;
  selectInstance: (pageKey: string, instanceId: string) => void;
  clearInstanceSelection: () => void;
  setHover: (instanceId: string | null) => void;
  /** Selection arriving from the preview bridge (canvas click). */
  selectFromPreview: (pageKey: string | null, instanceId: string) => void;

  setViewport: (viewport: ViewportKey) => void;
  setBridgeStatus: (status: BridgeStatus, error?: string) => void;
  setPreviewPageKey: (pageKey: string) => void;
  recordBounds: (instanceId: string, bounds: StudioNodeBounds | null) => void;
  clearBounds: () => void;
  bumpFrame: () => void;
  setExplorerTab: (tab: ExplorerTab) => void;

  setPreviewNodeCatalog: (entries: { instanceId: string; componentId: string }[]) => void;
  previewNodeCatalog: Record<string, string>;

  stageProps: (pageKey: string, instanceId: string, props: Record<string, unknown>) => void;
  stageToken: (key: string, value: string | number) => void;
  stageTokenRemove: (key: string) => void;
  takePendingOps: () => WorkspaceOperation[];
  clearSaveError: () => void;
  invalidateAll: () => void;
}

export const store = create<EditorStore>((set, get) => ({
  meta: null,
  document: null,

  selection: { scope: 'page', pageKey: null, instanceId: null },
  hoverInstanceId: null,
  viewport: 'desktop',
  bridgeStatus: 'connecting',
  bridgeError: null,
  previewPageKey: null,
  bounds: {},
  frameNonce: 0,
  explorerTab: 'structure',

  pendingOps: [],
  lastSavedAt: null,
  saveError: null,
  previewNodeCatalog: {},

  setMeta: (meta) => set({ meta }),

  hydrateDocument: (document) => {
    const state = get();
    // First hydration also names the project if the manifest beat us here.
    set({
      document,
      meta:
        state.meta ??
        ({
          projectId: document.projectId,
          projectName: document.projectId,
          workspaceMode: document.workspaceMode,
        } satisfies EditorMeta),
    });
  },

  adoptServerDocument: (document, savedAt) =>
    set({
      document,
      lastSavedAt: savedAt,
      saveError: null,
    }),

  selectWorkspace: () =>
    set({
      selection: { scope: 'workspace', pageKey: null, instanceId: null },
      hoverInstanceId: null,
    }),

  selectPage: (pageKey) =>
    set({
      selection: { scope: 'page', pageKey, instanceId: null },
      hoverInstanceId: null,
    }),

  selectInstance: (pageKey, instanceId) =>
    set({
      selection: { scope: 'component', pageKey, instanceId },
    }),

  clearInstanceSelection: () => {
    const { selection } = get();
    set({
      selection: {
        scope: 'page',
        pageKey: selection.pageKey,
        instanceId: null,
      },
    });
  },

  setHover: (instanceId) => set({ hoverInstanceId: instanceId }),

  selectFromPreview: (pageKey, instanceId) => {
    const state = get();
    const settled = pageKey ?? state.selection.pageKey;
    set({
      selection: { scope: 'component', pageKey: settled, instanceId },
      explorerTab: 'layers',
    });
  },

  setViewport: (viewport) => set({ viewport }),
  setBridgeStatus: (status, error) =>
    set({ bridgeStatus: status, bridgeError: error ?? null }),
  setPreviewPageKey: (pageKey) => set({ previewPageKey: pageKey }),
  recordBounds: (instanceId, bounds) => {
    if (bounds) set({ bounds: { ...get().bounds, [instanceId]: bounds } });
  },
  clearBounds: () => set({ bounds: {} }),
  bumpFrame: () => set((s) => ({ frameNonce: s.frameNonce + 1 })),
  setExplorerTab: (tab) => set({ explorerTab: tab }),

  setPreviewNodeCatalog: (entries) =>
    set({
      previewNodeCatalog: Object.fromEntries(
        entries.map((e) => [e.instanceId, e.componentId]),
      ),
    }),

  stageProps: (pageKey, instanceId, props) => {
    const state = get();
    const document = state.document;
    if (!document) return;
    const layout = [...(document.pageLayouts?.[pageKey] ?? [])];
    const index = layout.findIndex((i) => (i.instanceId ?? `${pageKey}#${layout.indexOf(i)}`) === instanceId);
    if (index < 0) return;
    const current = layout[index];
    layout[index] = {
      ...current,
      props: { ...current.props, ...props },
    };

    set({
      document: {
        ...document,
        pageLayouts: { ...document.pageLayouts, [pageKey]: layout },
        isDirty: true,
      },
      pendingOps: [
        ...state.pendingOps,
        { op: 'node.updateProps', pageKey, instanceId, props },
      ],
    });
  },

  /** Stages a single canonical design-token change (Workspace scope). */
  stageToken: (key, value) => {
    const state = get();
    const document = state.document;
    if (!document) return;
    set({
      document: {
        ...document,
        globalTokens: { ...document.globalTokens, [key]: value },
        isDirty: true,
      },
      pendingOps: [...state.pendingOps, { op: 'token.update', key, value }],
    });
  },

  /** Stages the removal of a canonical design token (back to template default). */
  stageTokenRemove: (key) => {
    const state = get();
    const document = state.document;
    if (!document) return;
    const globalTokens = { ...document.globalTokens };
    delete globalTokens[key];
    set({
      document: { ...document, globalTokens, isDirty: true },
      pendingOps: [...state.pendingOps, { op: 'token.remove', key }],
    });
  },

  takePendingOps: () => {
    const ops = get().pendingOps;
    set({ pendingOps: [] });
    return ops;
  },

  clearSaveError: () => set({ saveError: null }),

  invalidateAll: () =>
    set({
      pendingOps: [],
      bounds: {},
      lastSavedAt: Date.now(),
    }),
}));

/** Imperative accessor for hooks that need the current selection. */
export function getSelection(): EditorSelection & { bounds: Record<string, StudioNodeBounds> } {
  const state = store.getState();
  return { ...state.selection, bounds: state.bounds };
}
