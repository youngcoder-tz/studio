// studio/src/lib/gnapex-studio/visual-ir.ts
//
// THE VISUAL IR — THE DERIVATION LAYER.
//
// The GN-Apex contract is the architecture. This module is where the raw
// backend truth (the manifest's component contracts + the workspace document)
// becomes the editor's working representation:
//
//   Workspace Mode Contract + Document
//        │
//        ▼
//   Application Directory  (mode-aware navigation areas)
//   Page IR                (ordered nodes, editability classified per field)
//
// It exists so the Studio never has to guess editability from rendered DOM and
// never invents structure the contract does not declare. Anything not in the
// contract simply is not offered to the client.

import type {
  LayoutInstance,
  ManifestField,
  PageDefinition,
  StudioManifest,
  WorkspaceDocument,
  WorkspaceMode,
} from '../contract';
import {
  classifyField,
  type DirectoryArea,
  type DirectoryEntry,
  type DirectoryGroup,
  type IRNode,
  type IRNodeGroup,
  type PageIR,
} from './types';

// ─────────────────────────────────────────────────────────────────────────────
// PAGE CATALOG NORMALIZATION
// ─────────────────────────────────────────────────────────────────────────────

function humanizeKey(key: string): string {
  return key
    .split(/[._-]+/)
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(' ');
}

/**
 * The catalog is pedagogically string-or-object server-side; normalizing here
 * means a backend that speaks either shape renders identically.
 */
export function normalizePageCatalog(catalog: unknown): PageDefinition[] {
  if (!Array.isArray(catalog)) return [];
  const out: PageDefinition[] = [];
  for (const raw of catalog) {
    if (typeof raw === 'string') {
      out.push({ key: raw, label: humanizeKey(raw), required: false });
      continue;
    }
    if (raw && typeof raw === 'object') {
      const page = raw as Partial<PageDefinition> & Record<string, unknown>;
      if (typeof page.key !== 'string') continue;
      out.push({
        key: page.key,
        label: typeof page.label === 'string' ? page.label : humanizeKey(page.key),
        required: page.required === true,
      });
    }
  }
  return out;
}

// ─────────────────────────────────────────────────────────────────────────────
// DIRECTORY (mode-aware application areas)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Grouping rules per workspace mode. A page key matching the FIRST rule wins.
 * Unknown keys fall into the last group for the mode, so the directory always
 * stays honest to the contract while presenting mode-specific structure.
 */
const AREA_RULES: Record<
  WorkspaceMode,
  { area: Omit<DirectoryArea, 'key'> & { key?: string }; match: (key: string) => boolean }[]
> = {
  EDUCATION: [
    {
      area: { label: 'Public Website' },
      match: (k) => !k.startsWith('edu.') && !isSystemPage(k),
    },
    {
      area: { label: 'Academic Portal' },
      match: (k) =>
        ['edu.results', 'edu.fees', 'edu.attendance', 'edu.timetable'].includes(k),
    },
    {
      area: { label: 'Administration' },
      match: (k) => k === 'edu.staff' || k === 'edu.admissions',
    },
    {
      area: { label: 'Workspace Content' },
      match: (k) => isSystemPage(k),
    },
    { area: { label: 'Application Pages' }, match: () => true },
  ],
  NON_PROFIT: [
    {
      area: { label: 'Public Website' },
      match: (k) => !isSystemPage(k),
    },
    {
      area: { label: 'Workspace Content' },
      match: (k) => isSystemPage(k),
    },
  ],
  GENERAL: [
    { area: { label: 'Public Website' }, match: (k) => !isSystemPage(k) },
    { area: { label: 'Workspace Content' }, match: (k) => isSystemPage(k) },
  ],
  E_COMMERCE: [
    { area: { label: 'Storefront' }, match: (k) => !isSystemPage(k) },
    { area: { label: 'Workspace Content' }, match: (k) => isSystemPage(k) },
  ],
  PARTNER: [
    { area: { label: 'Partner Portal' }, match: (k) => !isSystemPage(k) },
    { area: { label: 'Workspace Content' }, match: (k) => isSystemPage(k) },
  ],
};

/** Keys that configure shared workspace surfaces rather than visitor pages. */
function isSystemPage(key: string): boolean {
  return ['content', 'forms', 'seo', 'ai.chat'].includes(key);
}

/** The provisioned mode's display name, for headers and the breadcrumb root. */
export const MODE_OS_NAMES: Record<WorkspaceMode, string> = {
  EDUCATION: 'EduOS',
  NON_PROFIT: 'NGO OS',
  GENERAL: 'General OS',
  E_COMMERCE: 'Commerce OS',
  PARTNER: 'Partner OS',
};

/**
 * Builds the application directory: the Workspace Design area (virtual) plus
 * every contract page grouped by modeaware areas. Entries the document has
 * provisioned are marked so the client sees what has live content.
 */
export function buildDirectory(
  manifest: StudioManifest,
  document: WorkspaceDocument,
): DirectoryGroup[] {
  const pages = normalizePageCatalog(manifest?.pageCatalog ?? []);
  const workspaceArea: DirectoryArea = {
    key: 'gnapex.design',
    label: 'Workspace Design',
    design: true,
  };

  const groups: DirectoryGroup[] = [{ area: workspaceArea, entries: [] }];

  const rules = AREA_RULES[manifest.workspaceMode] ?? AREA_RULES.GENERAL;
  const areaByKey = new Map<string, DirectoryArea>();
  for (const rule of rules) {
    const area: DirectoryArea = {
      key: `area:${rule.area.label.toLowerCase().replace(/\s+/g, '-')}`,
      label: rule.area.label,
    };
    groups.push({ area, entries: [] });
    for (const page of pages) {
      if (rule.match(page.key)) {
        areaByKey.set(page.key, area);
      }
    }
  }

  for (const page of pages) {
    const area = areaByKey.get(page.key);
    if (!area) continue;
    const group = groups.find((g) => g.area.key === area.key);
    if (!group) continue;
    const entry: DirectoryEntry = {
      page,
      provisioned: Boolean(document.pageLayouts?.[page.key]?.length),
      areaKey: area.key,
    };
    group.entries.push(entry);
  }

  return groups.filter((g) => g.area.design || g.entries.length > 0);
}

/** The default page to open: a provisioned contract page, else the manifest's default. */
export function resolveInitialPageKey(
  manifest: StudioManifest,
  document: WorkspaceDocument,
): string {
  const pages = normalizePageCatalog(manifest.pageCatalog);
  const provisioned = pages.find((p) => Boolean(document.pageLayouts?.[p.key]?.length));
  return provisioned?.key ?? pages[0]?.key ?? manifest.defaultPageKey;
}

// ─────────────────────────────────────────────────────────────────────────────
// PAGE IR
// ─────────────────────────────────────────────────────────────────────────────

/** Capabilities that translate into the "locked" statement for functional nodes. */
const PROTECTED_CAPABILITY_PATTERN =
  /auth|submit|validation|permission|rbac|payment|data|api|route|session/i;

function protectedNoticeFor(
  capabilities: string[],
  componentName: string,
): { topics: string[]; notice: string } {
  const functional = capabilities.filter((c) => PROTECTED_CAPABILITY_PATTERN.test(c));
  if (functional.length === 0) {
    return {
      topics: [],
      notice: '',
    };
  }
  const topics = ['application behaviour', 'data & permissions'];
  return {
    topics,
    notice: `${componentName}'s ${topics.join(' and ')} are managed by GN-Apex. You can customise how it looks and reads — not what it does.`,
  };
}

/**
 * Derives the page IR: one node per document instance in document order, with
 * the contract's field set classified into inspector groups.
 *
 * `instanceId` falls back to the document-order key `pageKey#index`, which is
 * the exact same fallback the SDK bridge stamps into `data-apex-instance`, so
 * document selection and preview selection agree even for instances that were
 * never assigned a stable id.
 */
export function buildPageIR(
  manifest: StudioManifest,
  document: WorkspaceDocument,
  pageKey: string,
): PageIR {
  const pages = normalizePageCatalog(manifest?.pageCatalog ?? []);
  const page = pages.find((p) => p.key === pageKey);
  const byId = new Map((manifest?.components ?? []).map((c) => [c.id, c]));
  const instances: LayoutInstance[] = document?.pageLayouts?.[pageKey] ?? [];

  const nodes: IRNode[] = instances.map((instance, index) => {
    const orderKey = `${pageKey}#${index}`;
    const manifestFor = byId.get(instance.componentId);
    const componentName = manifestFor?.name ?? instance.componentId;

    const groups: Record<IRNodeGroup, ManifestField[]> = {
      content: [],
      appearance: [],
      settings: [],
    };
    for (const field of manifestFor?.fields ?? []) {
      groups[classifyField(field)].push(field);
    }

    const { topics, notice } = protectedNoticeFor(
      manifestFor?.capabilities ?? [],
      componentName,
    );

    return {
      instanceId: instance.instanceId ?? orderKey,
      orderKey,
      componentId: instance.componentId,
      componentName,
      componentDescription: manifestFor?.description ?? null,
      category: manifestFor?.category ?? 'unknown',
      props: { ...(manifestFor?.defaultProps ?? {}), ...(instance.props ?? {}) },
      layout: instance.layout,
      contractKnown: Boolean(manifestFor),
      contentFields: groups.content,
      appearanceFields: groups.appearance,
      settingFields: groups.settings,
      protectedNotice: notice,
      protectedTopics: topics,
    };
  });

  return {
    pageKey,
    pageLabel: page?.label ?? humanizeKey(pageKey),
    required: page?.required ?? false,
    nodes,
  };
}
