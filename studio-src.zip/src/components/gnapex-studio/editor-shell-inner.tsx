// studio/src/components/gnapex-studio/editor-shell-inner.tsx

"use client";

import { useEffect, useMemo } from "react";
import Link from "next/link";
import { DoorOpen, Loader2 } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Toaster } from "sonner";

import { useManifest, useWorkspaceDocument } from "@/lib/api/hooks";
import { mintPreviewToken } from "@/lib/api/workspace";
import { store } from "@/lib/gnapex-studio/store";
import { portalOrigin } from "@/lib/gnapex-studio/bridge-protocol";
import { resolveInitialPageKey } from "@/lib/gnapex-studio/visual-ir";
import { useAutosave } from "@/hooks/gnapex-studio/use-autosave";
import { StudioShell } from "@/components/gnapex-studio/shell/studio-shell";

export default function EditorShellInner({ projectId }: { projectId: string }) {
  const manifestQuery = useManifest(projectId);
  const documentQuery = useWorkspaceDocument(projectId, true);
  const selectionPageKey = store((s) => s.selection?.pageKey);
  const hasTemplate = !!documentQuery.data?.templateId;

  useAutosave(projectId, hasTemplate);

  const initialPageKey = useMemo(() => {
    if (!manifestQuery.data) return null;
    if (!documentQuery.data) return manifestQuery.data.defaultPageKey ?? null;
    try {
      return resolveInitialPageKey(manifestQuery.data, documentQuery.data);
    } catch {
      return manifestQuery.data.defaultPageKey ?? null;
    }
  }, [documentQuery.data, manifestQuery.data]);

  const tokenQuery = useQuery({
    queryKey: ["gnapex-preview-token-v4", projectId],
    queryFn: async () => {
      const res = await mintPreviewToken(projectId);
      if (!res?.ok || !res?.token) throw new Error(res?.reason || "preview token failed");
      return res.token as string;
    },
    enabled: hasTemplate,
    retry: false,
    staleTime: 300000,
  });

  useEffect(() => {
    if (manifestQuery.data && projectId) {
      try {
        store.getState().setMeta({
          projectId,
          projectName: manifestQuery.data.projectName,
          workspaceMode: manifestQuery.data.workspaceMode,
        });
      } catch {}
    }
  }, [manifestQuery.data, projectId]);

  useEffect(() => {
    if (documentQuery.data) {
      try {
        store.getState().hydrateDocument(documentQuery.data);
      } catch {}
    }
  }, [documentQuery.data]);

  useEffect(() => {
    if (!initialPageKey) return;
    try {
      const sel = store.getState().selection;
      if (!sel?.pageKey) {
        store.getState().selectPage(initialPageKey);
      }
    } catch {}
  }, [initialPageKey]);

  const isPending = manifestQuery.isPending || documentQuery.isPending;
  const isError = manifestQuery.isError || !manifestQuery.data;
  const notCommissioned = !isPending && !isError && !hasTemplate;

  if (isPending) {
    return (
      <div className="flex h-dvh flex-col items-center justify-center gap-3 bg-[#090A0F] text-gray-400">
        <Loader2 className="size-6 animate-spin text-[#00D4FF]" />
        <p className="text-[11px] font-mono uppercase tracking-widest">Fetching the workspace contract…</p>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="flex h-dvh flex-col items-center justify-center gap-3 bg-[#090A0F]">
        <span className="text-[13px] text-red-400">The workspace contract could not be loaded.</span>
        <p className="text-[11px] font-mono uppercase tracking-widest text-gray-600">GN-Apex Studio</p>
      </div>
    );
  }

  if (notCommissioned) {
    return (
      <div className="flex h-dvh flex-col items-center justify-center gap-4 bg-[#090A0F] text-gray-300">
        <DoorOpen className="size-8 text-[#00D4FF]" />
        <p className="text-[14px] font-semibold">This workspace has not been commissioned yet</p>
        <p className="max-w-sm text-center text-[12px] leading-relaxed text-gray-500">
          The Studio opens a provisioned workspace OS. Run the commissioning wizard once.
        </p>
        <Link href={`/studio/${projectId}/setup`} className="rounded-lg bg-[#00D4FF] px-4 py-2 text-[13px] font-semibold text-[#090A0F] hover:opacity-90">
          Open commissioning
        </Link>
        <Toaster position="bottom-right" />
      </div>
    );
  }

  let previewOrigin = "";
  try {
    previewOrigin = portalOrigin(process.env.NEXT_PUBLIC_PORTAL_ORIGIN || null) || (typeof window !== "undefined" ? window.location.origin : "");
  } catch {
    previewOrigin = typeof window !== "undefined" ? window.location.origin : "";
  }

  const framedPageKey = selectionPageKey ?? initialPageKey ?? "home";

  return (
    <>
      <StudioShell
        projectId={projectId}
        manifest={manifestQuery.data}
        document={documentQuery.data}
        previewToken={tokenQuery.data ?? null}
        previewOrigin={previewOrigin}
        framedPageKey={framedPageKey}
      />
      <Toaster position="bottom-right" />
    </>
  );
}
