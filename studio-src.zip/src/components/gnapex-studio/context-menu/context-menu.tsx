// studio/src/components/gnapex-studio/context-menu/context-menu.tsx

'use client';

import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Copy, Edit3, Eye, EyeOff, Layers, MousePointer2, Move, Trash2 } from 'lucide-react';
import { store } from '@/lib/gnapex-studio/store';

interface MenuItem {
  label: string;
  icon: React.ReactNode;
  shortcut?: string;
  danger?: boolean;
  onClick?: () => void;
  divider?: boolean;
}

export function CanvasContextMenu() {
  const [open, setOpen] = useState(false);
  const [pos, setPos] = useState({ x: 0, y: 0 });
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (target.closest('[data-gnapex-canvas]')) {
        e.preventDefault();
        setPos({ x: e.clientX, y: e.clientY });
        setOpen(true);
      }
    };
    const close = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    const esc = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    window.addEventListener('contextmenu', handler);
    window.addEventListener('click', close);
    window.addEventListener('keydown', esc);
    return () => {
      window.removeEventListener('contextmenu', handler);
      window.removeEventListener('click', close);
      window.removeEventListener('keydown', esc);
    };
  }, []);

  const items: MenuItem[] = [
    { label: 'Select element', icon: <MousePointer2 className="size-3.5" />, shortcut: 'Click' },
    { label: 'Edit content', icon: <Edit3 className="size-3.5" />, shortcut: 'DblClick', divider: true },
    { label: 'Move', icon: <Move className="size-3.5" /> },
    { label: 'Duplicate', icon: <Copy className="size-3.5" />, shortcut: '⌘D' },
    { label: 'View in layers', icon: <Layers className="size-3.5" />, onClick: () => { store.getState().setExplorerTab('layers'); setOpen(false); } },
    { label: 'Hide', icon: <EyeOff className="size-3.5" />, divider: true },
    { label: 'Show all', icon: <Eye className="size-3.5" /> },
    { label: 'Delete', icon: <Trash2 className="size-3.5" />, shortcut: 'Del', danger: true },
  ];

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          ref={ref}
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.98 }}
          transition={{ duration: 0.12 }}
          className="fixed z-[99998] min-w-[200px] overflow-hidden rounded-xl border border-white/10 bg-[#0B0D14]/95 p-1 shadow-[0_60px_120px_-60px_rgba(0,212,255,0.3)] backdrop-blur-xl"
          style={{ left: pos.x, top: pos.y }}
        >
          {items.map((item, i) => (
            <div key={i}>
              {item.divider && <div className="my-1 h-px bg-white/5" />}
              <button
                onClick={() => { item.onClick?.(); if (!item.onClick) setOpen(false); }}
                className={`flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left text-[12px] transition-colors ${
                  item.danger ? 'text-red-400 hover:bg-red-500/10' : 'text-gray-400 hover:bg-white/[0.06] hover:text-gray-200'
                }`}
              >
                {item.icon}
                <span className="flex-1">{item.label}</span>
                {item.shortcut && <span className="font-mono text-[10px] text-gray-600">{item.shortcut}</span>}
              </button>
            </div>
          ))}
        </motion.div>
      )}
    </AnimatePresence>
  );
}
