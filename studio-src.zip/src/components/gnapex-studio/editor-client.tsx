// studio/src/components/gnapex-studio/editor-client.tsx
// THE EDITOR BOOT ROOT.

"use client";

import { use, useState } from "react";
import dynamic from "next/dynamic";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";

const EditorShellInner = dynamic(() => import("./editor-shell-inner"), {
  ssr: false,
});

export default function EditorClient({
  params,
}: {
  params: Promise<{ projectId: string }>;
}) {
  const resolved = use(params);

  // Provide a local QueryClient instance to prevent 'reading inst of null'
  // if QueryClientProvider is missing from the parent layout root.
  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            staleTime: 1000 * 60 * 5,
            refetchOnWindowFocus: false,
          },
        },
      }),
  );

  return (
    <QueryClientProvider client={queryClient}>
      <EditorShellInner projectId={resolved.projectId} />
    </QueryClientProvider>
  );
}
