// studio/src/components/gnapex-studio/canvas/preview-frame.tsx
//
// THE LIVE CANVAS.
//
// Frames the actual provisioned portal (its own origin, its own runtime) —
// not an approximation — and connects the GN-Apex preview bridge. Selection,
// hover and geometry flow both ways as typed envelopes; the Studio never
// inspects the frame's DOM.
//
// The frame remounts when the framed page changes (an iframe cannot push its
// own history without fighting the real router), and the selection overlay is
// a sibling layer whose coordinate space matches the frame's viewport
// exactly (1:1, no zoom in this phase).

'use client';

import { useEffect, useMemo, useRef } from 'react';
import { Loader2, MousePointerClick, PlugZap } from 'lucide-react';

import { usePreviewBridge } from '@/hooks/gnapex-studio/use-preview-bridge';
import { store } from '@/lib/gnapex-studio/store';
import { previewPathFor } from '@/lib/preview';
import { VIEWPORTS } from '@/lib/gnapex-studio/types';
import { SelectionOverlay } from './selection-overlay';
import { FloatingToolbar } from './floating-toolbar';
import { ZoomControls } from './zoom-controls';

export function PreviewFrame({
  projectId,
  pageKey,
  previewToken,
  resolvedOrigin,
}: {
  projectId: string;
  pageKey: string;
  previewToken: string | null;
  /** Absolute origin used for both the frame src and bridge validation. */
  resolvedOrigin: string;
}) {
  const frameRef = useRef<HTMLIFrameElement | null>(null);
  const viewport = store((s) => s.viewport);
  const bridgeStatus = store((s) => s.bridgeStatus);
  const setBridgeStatus = store((s) => s.setBridgeStatus);

  usePreviewBridge({
    projectId,
    pageKey,
    previewOrigin: resolvedOrigin,
    frameRef,
    enabled: true,
  });

  const frameSrc = useMemo(() => {
    const path = previewPathFor(pageKey);
    const params = new URLSearchParams();
    params.set('preview', 'draft');
    params.set('_preview', 'true');
    if (previewToken) params.set('previewKey', previewToken);
    params.set('projectId', projectId);
    params.set('_studio', '1');
    const studioOrigin =
      typeof window !== 'undefined' ? window.location.origin : '';
    if (studioOrigin) params.set('studioOrigin', studioOrigin);
    const base = resolvedOrigin ? resolvedOrigin.replace(/\/$/, '') : '';
    return `${base}${path}?${params.toString()}`;
  }, [pageKey, previewToken, projectId, resolvedOrigin]);

  // Reset bridge assumptions whenever the frame identity changes.
  useEffect(() => {
    setBridgeStatus('connecting');
  }, [frameSrc, setBridgeStatus]);

  const width = VIEWPORTS[viewport].width;

  return (
    <div className="relative flex h-full min-h-0 w-full items-stretch justify-center overflow-auto bg-[#07080C]">
      <div
        className="relative h-full shrink-0 border-white/10 bg-white"
        style={{ width }}
      >
        <iframe
          key={frameSrc}
          ref={frameRef}
          src={frameSrc}
          title={`GN-Apex preview — ${pageKey}`}
          className="block h-full w-full border-0 bg-white"
          // The frame is the real application; scripts run, but the browser
          // keeps its context isolated from the Studio.
          sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
        />
        <SelectionOverlay />
        <FloatingToolbar />
        <ZoomControls />
      </div>

      {bridgeStatus === 'connecting' ? (
        <div className="absolute bottom-4 left-1/2 z-10 flex -translate-x-1/2 items-center gap-2 rounded-full border border-[#00D4FF]/30 bg-[#090A0F]/90 px-3 py-1.5 text-[11px] font-mono uppercase tracking-wider text-[#00D4FF]">
          <Loader2 className="size-3 animate-spin" />
          Establishing bridge
        </div>
      ) : null}

      {bridgeStatus === 'unavailable' ? (
        <div className="absolute bottom-4 left-1/2 z-10 flex max-w-md -translate-x-1/2 items-center gap-2 rounded-full border border-amber-400/30 bg-[#090A0F]/90 px-3 py-1.5 text-[11px] font-mono uppercase tracking-wider text-amber-300">
          <PlugZap className="size-3 shrink-0" />
          Editing surface inactive — restart the portal runtime to stream selection
        </div>
      ) : null}

      {bridgeStatus === 'active' ? (
        <div className="pointer-events-none absolute bottom-4 left-1/2 z-10 flex -translate-x-1/2 items-center gap-2 rounded-full border border-white/10 bg-[#090A0F]/90 px-3 py-1.5 text-[11px] font-mono uppercase tracking-wider text-gray-400">
          <MousePointerClick className="size-3 text-[#00D4FF]" />
          Click a section in the live application to customise it
        </div>
      ) : null}
    </div>
  );
}
