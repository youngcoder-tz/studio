// studio/src/components/gnapex-studio/canvas/floating-toolbar.tsx
//
// FLOATING CONTEXT TOOLBAR
//
// Appears above the currently selected component with contextual actions.
// Driven by bridge bounds, never DOM scraping.

'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { Copy, EyeOff, Layers, MousePointer2, Move, Trash2 } from 'lucide-react';
import { store } from '@/lib/gnapex-studio/store';
import { useMemo } from 'react';

export function FloatingToolbar() {
  const selection = store((s) => s.selection);
  const bounds = store((s) => s.bounds);
  const bridgeStatus = store((s) => s.bridgeStatus);

  const isActive = useMemo(() => {
    return bridgeStatus === 'active' && selection.scope === 'component' && selection.instanceId && bounds[selection.instanceId];
  }, [bridgeStatus, selection.scope, selection.instanceId, bounds]);

  if (!isActive || !selection.instanceId) return null;

  const b = bounds[selection.instanceId];
  const top = Math.max(b.y - 44, 8);
  const left = b.x + b.width / 2;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 6, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 6, scale: 0.98 }}
        transition={{ duration: 0.16, ease: [0.25, 0.8, 0.25, 1] }}
        className="pointer-events-auto absolute z-[20] -translate-x-1/2"
        style={{ top, left }}
      >
        <div className="flex items-center gap-0.5 rounded-xl border border-white/10 bg-[#0B0D14]/95 px-1 py-1 shadow-[0_40px_80px_-40px_rgba(0,212,255,0.4)] backdrop-blur-xl">
          <ToolbarBtn icon={<MousePointer2 className="size-3.5" />} label="Select" active />
          <Divider />
          <ToolbarBtn icon={<Move className="size-3.5" />} label="Move" />
          <ToolbarBtn icon={<Copy className="size-3.5" />} label="Duplicate" />
          <ToolbarBtn icon={<Layers className="size-3.5" />} label="Layers" onClick={() => store.getState().setExplorerTab('layers')} />
          <Divider />
          <ToolbarBtn icon={<EyeOff className="size-3.5" />} label="Hide" />
          <ToolbarBtn icon={<Trash2 className="size-3.5" />} label="Remove" danger />
        </div>
      </motion.div>
    </AnimatePresence>
  );
}

function ToolbarBtn({ icon, label, active, danger, onClick }: { icon: React.ReactNode; label: string; active?: boolean; danger?: boolean; onClick?: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      title={label}
      className={`group relative flex items-center gap-1.5 rounded-lg px-2 py-1.5 text-[11px] transition-all ${
        active
          ? 'bg-[#00D4FF]/15 text-[#00D4FF]'
          : danger
            ? 'text-red-400 hover:bg-red-500/10'
            : 'text-gray-400 hover:bg-white/[0.06] hover:text-gray-200'
      }`}
    >
      {icon}
      <span className="hidden sm:inline">{label}</span>
    </button>
  );
}

function Divider() {
  return <div className="mx-1 h-5 w-px bg-white/10" />;
}
