// studio/src/components/gnapex-studio/canvas/zoom-controls.tsx

'use client';

import { Minus, Plus, Maximize2 } from 'lucide-react';
import { useState } from 'react';
import { motion } from 'framer-motion';

export function ZoomControls() {
  const [zoom, setZoom] = useState(100);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="absolute bottom-4 right-4 z-10 flex items-center gap-0.5 rounded-xl border border-white/10 bg-[#0B0D14]/95 p-1 shadow-2xl backdrop-blur-xl"
    >
      <button onClick={() => setZoom((z) => Math.max(25, z - 25))} className="rounded-lg p-1.5 text-gray-500 hover:bg-white/5 hover:text-gray-300">
        <Minus className="size-3.5" />
      </button>
      <button className="px-2 font-mono text-[11px] text-gray-400">{zoom}%</button>
      <button onClick={() => setZoom((z) => Math.min(200, z + 25))} className="rounded-lg p-1.5 text-gray-500 hover:bg-white/5 hover:text-gray-300">
        <Plus className="size-3.5" />
      </button>
      <div className="mx-1 h-4 w-px bg-white/10" />
      <button onClick={() => setZoom(100)} className="rounded-lg p-1.5 text-gray-500 hover:bg-white/5 hover:text-gray-300">
        <Maximize2 className="size-3.5" />
      </button>
    </motion.div>
  );
}
