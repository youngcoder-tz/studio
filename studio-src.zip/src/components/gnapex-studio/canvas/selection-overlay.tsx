// studio/src/components/gnapex-studio/canvas/selection-overlay.tsx
//
// THE OVERLAY LAYER.
//
// Pure presentation: draws the selected/hover outlines from bridge-reported
// bounds. It renders nothing when the bridge is quiet — bounds values arrive
// only through validated envelopes, never from DOM measurement.

'use client';

import { store } from '@/lib/gnapex-studio/store';

export function SelectionOverlay() {
  const bridgeStatus = store((s) => s.bridgeStatus);
  const selection = store((s) => s.selection);
  const hoverInstanceId = store((s) => s.hoverInstanceId);
  const bounds = store((s) => s.bounds);

  if (bridgeStatus !== 'active') return null;
  if (selection.scope === 'workspace') return null;

  const selectedBounds =
    selection.scope === 'component' && selection.instanceId
      ? bounds[selection.instanceId]
      : undefined;
  const hoverBounds = hoverInstanceId ? bounds[hoverInstanceId] : undefined;

  return (
    <div
      className="pointer-events-none absolute inset-0 z-[5]"
      role="presentation"
    >
      {hoverBounds && hoverInstanceId !== selection.instanceId ? (
        <div
          className="absolute border-[1.5px] border-[#00D4FF]/50"
          style={{
            left: hoverBounds.x,
            top: hoverBounds.y,
            width: hoverBounds.width,
            height: hoverBounds.height,
          }}
        />
      ) : null}

      {selectedBounds && selection.instanceId ? (
        <>
          <div
            className="absolute border-2 border-[#00D4FF] shadow-[0_0_0_1px_rgba(0,212,255,0.25)]"
            style={{
              left: selectedBounds.x,
              top: selectedBounds.y,
              width: selectedBounds.width,
              height: selectedBounds.height,
            }}
          />
          <div
            className="absolute -translate-y-full bg-[#00D4FF] px-1.5 py-0.5 font-mono text-[10px] font-bold uppercase tracking-wider text-[#090A0F]"
            style={{
              left: selectedBounds.x,
              top: Math.max(selectedBounds.y, 18),
            }}
          >
            🎯 selected
          </div>
        </>
      ) : null}
    </div>
  );
}
