// studio/src/components/gnapex-studio/ui/glass-panel.tsx
//
// GLASS PANEL UTILITY
//
// Consistent frosted glass styling used across the studio

import { cn } from '@/lib/utils';

export function GlassPanel({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        'relative overflow-hidden rounded-xl border border-white/10 bg-gradient-to-b from-white/[0.04] to-white/[0.02] backdrop-blur-xl',
        'shadow-[0_60px_120px_-60px_rgba(0,212,255,0.15)]',
        className,
      )}
    >
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#00D4FF]/40 to-transparent" />
      {children}
    </div>
  );
}
