// studio/src/components/gnapex-studio/command-palette/command-palette.tsx
//
// THE COMMAND PALETTE.
//
// Jump anywhere in the provisioned OS at lightning speed: pages, sections,
// workspace design, panels, viewport, publish, preview. Powered by cmdk.

'use client';

import { useEffect, useState } from 'react';
import { Command } from 'cmdk';
import {
  ArrowRight,
  Command as CommandIcon,
  Download,
  LayoutGrid,
  Monitor,
  Paintbrush,
  Search,
  Smartphone,
  TabletSmartphone,
} from 'lucide-react';

import { useManifest } from '@/lib/api/hooks';
import { store } from '@/lib/gnapex-studio/store';
import { buildDirectory } from '@/lib/gnapex-studio/visual-ir';
import { VIEWPORTS, type ViewportKey } from '@/lib/gnapex-studio/types';

export function CommandPalette({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const [query, setQuery] = useState('');
  // Self-sufficient: the palette sources the workspace structure itself so the
  // shell stays a thin composer (same pattern as the contextual inspector).
  const meta = store((s) => s.meta);
  const document_ = store((s) => s.document);
  const { data: manifest } = useManifest(meta?.projectId ?? '');
  const groups =
    manifest && document_ ? buildDirectory(manifest, document_) : [];

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === 'k' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        onOpenChange(!open);
      }
      if (e.key === 'Escape') onOpenChange(false);
    };
    document.addEventListener('keydown', down);
    return () => document.removeEventListener('keydown', down);
  }, [onOpenChange, open]);

  useEffect(() => {
    if (open) return;
    // Reset the search whenever the palette is closed (safe: converges).
    setQuery('');
  }, [open]);

  if (!open) {
    return null;
  }

  return (
    <div className="fixed inset-0 z-[9999] flex items-start justify-center bg-black/60 pt-[18vh] backdrop-blur-sm">
      <div
        className="w-full max-w-xl overflow-hidden rounded-2xl border border-white/10 bg-[#0B0D14]/95 shadow-[0_80px_160px_-80px_rgba(0,212,255,0.25)]"
        onClick={(e) => e.stopPropagation()}
      >
        <Command className="[&_[cmdk-input-wrapper]_svg]:text-gray-500 [&_[cmdk-item]]:aria-selected:bg-white/[0.06]" loop>
          <div className="flex items-center gap-2 border-b border-white/10 px-4">
            <Search className="size-4 text-gray-500" />
            <Command.Input
              value={query}
              onValueChange={setQuery}
              placeholder="Jump to pages, sections, design, actions..."
              className="h-12 flex-1 bg-transparent text-[13px] text-gray-200 outline-none placeholder:text-gray-600"
            />
            <div className="flex items-center gap-1 rounded-md border border-white/10 px-1.5 py-0.5 text-[10px] font-mono text-gray-600">
              <CommandIcon className="size-3" />
              K
            </div>
          </div>

          <Command.List className="max-h-[420px] overflow-y-auto p-2">
            <Command.Empty className="px-3 py-8 text-center text-[12px] text-gray-600">
              Nothing matches &quot;{query}&quot;
            </Command.Empty>

            <Command.Group
              heading="Workspace Design"
              className="[&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:py-1.5 [&_[cmdk-group-heading]]:text-[10px] [&_[cmdk-group-heading]]:font-mono [&_[cmdk-group-heading]]:uppercase [&_[cmdk-group-heading]]:tracking-wider [&_[cmdk-group-heading]]:text-gray-600"
            >
              <Command.Item
                onSelect={() => {
                  store.getState().selectWorkspace();
                  onOpenChange(false);
                }}
                className="flex cursor-pointer items-center gap-2 rounded-lg px-2 py-2 text-[13px] text-gray-300 aria-selected:text-gray-100"
              >
                <Paintbrush className="size-4 text-[#00D4FF]" />
                <span className="flex-1">Open Workspace Design</span>
                <ArrowRight className="size-3 text-gray-700" />
              </Command.Item>
            </Command.Group>

            {groups
              .filter((g) => !g.area.design)
              .map((group) => (
                <Command.Group
                  key={group.area.key}
                  heading={group.area.label}
                  className="[&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:py-1.5 [&_[cmdk-group-heading]]:text-[10px] [&_[cmdk-group-heading]]:font-mono [&_[cmdk-group-heading]]:uppercase [&_[cmdk-group-heading]]:tracking-wider [&_[cmdk-group-heading]]:text-gray-600"
                >
                  {group.entries.map((entry) => (
                    <Command.Item
                      key={entry.page.key}
                      onSelect={() => {
                        store.getState().selectPage(entry.page.key);
                        onOpenChange(false);
                      }}
                      className="flex cursor-pointer items-center gap-2 rounded-lg px-2 py-2 text-[13px] text-gray-300 aria-selected:text-gray-100"
                    >
                      <LayoutGrid className="size-4 text-gray-500" />
                      <span className="flex-1 truncate">{entry.page.label}</span>
                      <span className="text-[10px] font-mono text-gray-700">
                        {entry.page.key}
                      </span>
                    </Command.Item>
                  ))}
                </Command.Group>
              ))}

            <Command.Group
              heading="Viewport"
              className="[&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:py-1.5 [&_[cmdk-group-heading]]:text-[10px] [&_[cmdk-group-heading]]:font-mono [&_[cmdk-group-heading]]:uppercase [&_[cmdk-group-heading]]:tracking-wider [&_[cmdk-group-heading]]:text-gray-600"
            >
              {(['desktop', 'tablet', 'mobile'] as ViewportKey[]).map((key) => {
                const Icon =
                  key === 'desktop'
                    ? Monitor
                    : key === 'tablet'
                      ? TabletSmartphone
                      : Smartphone;
                return (
                  <Command.Item
                    key={key}
                    onSelect={() => {
                      store.getState().setViewport(key);
                      onOpenChange(false);
                    }}
                    className="flex cursor-pointer items-center gap-2 rounded-lg px-2 py-2 text-[13px] text-gray-300 aria-selected:text-gray-100"
                  >
                    <Icon className="size-4 text-gray-500" />
                    <span className="flex-1">Switch to {VIEWPORTS[key].label}</span>
                    <span className="text-[10px] font-mono text-gray-700">
                      {VIEWPORTS[key].width}px
                    </span>
                  </Command.Item>
                );
              })}
            </Command.Group>

            <Command.Group
              heading="Actions"
              className="[&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:py-1.5 [&_[cmdk-group-heading]]:text-[10px] [&_[cmdk-group-heading]]:font-mono [&_[cmdk-group-heading]]:uppercase [&_[cmdk-group-heading]]:tracking-wider [&_[cmdk-group-heading]]:text-gray-600"
            >
              <Command.Item
                onSelect={() => onOpenChange(false)}
                className="flex cursor-pointer items-center gap-2 rounded-lg px-2 py-2 text-[13px] text-gray-300 aria-selected:text-gray-100"
              >
                <Download className="size-4 text-gray-500" />
                <span className="flex-1">Publish workspace</span>
                <span className="text-[10px] font-mono text-gray-700">⌘⇧P</span>
              </Command.Item>
            </Command.Group>
          </Command.List>
        </Command>
      </div>
      <div className="absolute inset-0" onClick={() => onOpenChange(false)} />
    </div>
  );
}
