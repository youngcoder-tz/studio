// studio/src/components/gnapex-studio/panels/assets-panel.tsx

'use client';

import { Image as ImageIcon, Upload, Search } from 'lucide-react';
import { useState } from 'react';

export function AssetsPanel() {
  const [query, setQuery] = useState('');

  return (
    <div className="flex h-full flex-col">
      <div className="border-b border-white/5 px-4 py-3">
        <h3 className="text-[13px] font-semibold text-gray-100">Assets</h3>
        <p className="text-[10px] font-mono uppercase tracking-wider text-gray-600">Media Library</p>
      </div>
      <div className="border-b border-white/5 px-3 py-2">
        <div className="flex items-center gap-2 rounded-lg border border-white/10 bg-white/[0.02] px-2 py-1.5">
          <Search className="size-3.5 text-gray-600" />
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search assets..." className="flex-1 bg-transparent text-[12px] text-gray-300 outline-none placeholder:text-gray-700" />
        </div>
      </div>
      <div className="flex flex-1 flex-col items-center justify-center gap-2 px-4 text-center">
        <div className="flex size-10 items-center justify-center rounded-xl bg-white/[0.03]">
          <ImageIcon className="size-5 text-gray-600" />
        </div>
        <p className="text-[12px] font-medium text-gray-400">No assets yet</p>
        <p className="text-[11px] leading-relaxed text-gray-600">Upload images, logos or icons to use across your workspace</p>
        <button className="mt-2 flex items-center gap-1.5 rounded-lg bg-white/[0.04] px-3 py-1.5 text-[11px] text-gray-300 hover:bg-white/[0.06]">
          <Upload className="size-3.5" /> Upload asset
        </button>
      </div>
    </div>
  );
}
