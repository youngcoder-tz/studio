// studio/src/components/gnapex-studio/panels/history-panel.tsx

'use client';

import { Clock, GitBranch } from 'lucide-react';
import { store } from '@/lib/gnapex-studio/store';

export function HistoryPanel() {
  const document_ = store((s) => s.document);

  return (
    <div className="flex h-full flex-col">
      <div className="border-b border-white/5 px-4 py-3">
        <h3 className="text-[13px] font-semibold text-gray-100">History</h3>
        <p className="text-[10px] font-mono uppercase tracking-wider text-gray-600">Revisions</p>
      </div>
      <div className="flex-1 overflow-y-auto p-2">
        <div className="space-y-1">
          <div className="flex items-start gap-2 rounded-lg bg-[#00D4FF]/[0.08] px-2 py-2">
            <div className="mt-0.5 flex size-5 items-center justify-center rounded-full bg-[#00D4FF]/20">
              <GitBranch className="size-3 text-[#00D4FF]" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <p className="text-[12px] text-gray-200">Draft revision</p>
                <span className="font-mono text-[10px] text-[#00D4FF]">r{document_?.draftRevision ?? 0}</span>
              </div>
              <p className="mt-0.5 text-[10px] text-gray-600">Current working copy</p>
            </div>
          </div>
          <div className="flex items-start gap-2 rounded-lg px-2 py-2 opacity-60">
            <div className="mt-0.5 flex size-5 items-center justify-center rounded-full bg-white/5">
              <Clock className="size-3 text-gray-500" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <p className="text-[12px] text-gray-400">Live revision</p>
                <span className="font-mono text-[10px] text-gray-600">r{document_?.liveRevision ?? 0}</span>
              </div>
              <p className="mt-0.5 text-[10px] text-gray-700">Published</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
