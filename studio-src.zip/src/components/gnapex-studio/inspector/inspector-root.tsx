// studio/src/components/gnapex-studio/inspector/inspector-root.tsx
//
// THE CONTEXTUAL INSPECTOR.
//
// Scope-aware, straight through the "Where am I?" grammar:
//
//   workspace    → Workspace Design System (tokens summary, global identity)
//   page         → page-level presentation + SEO
//   component    → contract fields grouped Content / Appearance / Settings
//
// The control surface comes from the manifest's `fields`; protected behaviour
// is stated in prose (🔒 Managed by GN-Apex), never offered as a control. There
// is deliberately no CSS / className / data-attribute surface for clients.

'use client';

import { useRef, useState } from 'react';
import { Lock, Palette, Settings2, ShieldCheck, Type } from 'lucide-react';

import { useManifest } from '@/lib/api/hooks';
import { store } from '@/lib/gnapex-studio/store';
import { buildPageIR } from '@/lib/gnapex-studio/visual-ir';
import { CANONICAL_TOKEN_KINDS, TOKEN_GROUPS } from '@/lib/contract';
import type { IRNode } from '@/lib/gnapex-studio/types';
import { validateTokenValue } from '@/lib/validate';
import { FieldControl } from './field-controls';

export function InspectorRoot() {
  const selection = store((s) => s.selection);
  const meta = store((s) => s.meta);

  return (
    <div className="flex h-full flex-col overflow-hidden bg-[#0B0D14]">
      <div className="flex-1 overflow-y-auto px-4 py-4">
        {selection.scope === 'component' ? (
          <ComponentInspector selection={selection} />
        ) : selection.scope === 'page' ? (
          <PageInspector pageKey={selection.pageKey} />
        ) : (
          <WorkspaceInspector />
        )}
      </div>
      {meta ? (
        <div className="shrink-0 border-t border-white/5 px-4 py-2.5">
          <p className="truncate text-[10px] font-mono uppercase tracking-wider text-gray-600">
            {meta.workspaceMode.replace('_', ' ')} · {selection.scope} scope
          </p>
        </div>
      ) : null}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// WORKSPACE SCOPE — the design system
// ─────────────────────────────────────────────────────────────────────────────

/** How template keys read on the banner, first-class template first. */
const TEMPLATE_DISPLAY_NAMES: Record<string, string> = {
  'edu-os-enterprise': 'Edu OS — Enterprise',
};

function templateDisplayName(templateId: string): string {
  return (
    TEMPLATE_DISPLAY_NAMES[templateId] ??
    templateId.replace(/-/g, ' ').replace(/(^|\s)\S/g, (c) => c.toUpperCase())
  );
}

function valueToText(value: unknown): string {
  if (value === undefined || value === null) return '';
  return String(value);
}

function kebabOf(key: string): string {
  return key.replace(/([A-Z])/g, (c) => `-${c.toLowerCase()}`);
}

function TemplateBanner({ templateId }: { templateId: string | null }) {
  if (!templateId) return null;
  return (
    <div className="rounded-xl border border-[#00D4FF]/20 bg-gradient-to-br from-[#00D4FF]/10 to-transparent p-3.5">
      <p className="flex items-center justify-between gap-2 text-[10px] font-mono uppercase tracking-wider text-[#00D4FF]">
        <span>Selected template</span>
        <ShieldCheck className="size-3.5 shrink-0" />
      </p>
      <p className="mt-1 text-[13px] font-semibold tracking-tight text-gray-100">
        {templateDisplayName(templateId)}
      </p>
      <p className="mt-1 text-[11px] leading-relaxed text-gray-500">
        Every page here is built from this template&apos;s portal. Tune the
        tokens below — the preview frame redresses live, autosave persists the
        draft, and the next publish takes it to your visitors.
      </p>
    </div>
  );
}

const TOKEN_LABEL_OVERRIDES: Record<string, string> = {
  borderRadius: 'Border radius',
  contentMaxWidth: 'Content max width',
  sectionSpacing: 'Section spacing',
  gridGutter: 'Grid gutter',
  logoUrl: 'Logo URL',
  ogImage: 'Share image',
};

function tokenLabel(key: string): string {
  return (
    TOKEN_LABEL_OVERRIDES[key] ??
    key.replace(/([A-Z])/g, ' $1').replace(/^./, (c) => c.toUpperCase())
  );
}

const TOKEN_PLACEHOLDERS: Record<string, string> = {
  primaryColor: '#2563eb',
  logoUrl: '/brand/logo.svg or https://…',
  fontHeading: 'ui-sans-serif, system-ui, …',
  fontBody: 'ui-sans-serif, system-ui, …',
  borderRadius: 'rounded · pill · 12px',
  contentMaxWidth: '72rem',
  sectionSpacing: '3rem',
  gridGutter: '1.25rem',
};

/** One editable canonical token. Blank commits a removal (template default). */
function TokenControl({ tokenKey }: { tokenKey: string }) {
  const document_ = store((s) => s.document);
  const value = document_?.globalTokens?.[tokenKey];
  const kind = CANONICAL_TOKEN_KINDS[tokenKey] ?? 'text';

  // Local text state keeps typing instant; commits debounce into the store.
  const [text, setText] = useState(valueToText(value));
  const [last, setLast] = useState(value);
  const commitTimer = useRef<number | undefined>(undefined);
  if (value !== last) {
    setLast(value);
    setText(valueToText(value));
  }

  const commit = (next: string) => {
    setText(next);
    window.clearTimeout(commitTimer.current);
    commitTimer.current = window.setTimeout(() => {
      const trimmed = next.trim();
      if (trimmed === '') {
        store.getState().stageTokenRemove(tokenKey);
        return;
      }
      store.getState().stageToken(tokenKey, trimmed);
    }, 350);
  };

  const problem =
    text.trim() === '' ? null : validateTokenValue(tokenKey, text.trim());

  const onChangeHex = (hex: string) => {
    setText(hex);
    store.getState().stageToken(tokenKey, hex);
  };

  const isNativeColor =
    kind === 'color' && /^#[0-9A-Fa-f]{6}([0-9A-Fa-f]{2})?$/.test(text.trim());

  if (kind === 'theme' || kind === 'direction') {
    const options =
      kind === 'theme'
        ? ['light', 'dark', 'system']
        : ['ltr', 'rtl'];
    return (
      <div className="space-y-1.5 rounded-lg border border-white/5 bg-white/[0.02] px-3 py-2">
        <p className="text-[10px] font-mono uppercase tracking-wider text-gray-500">
          {tokenLabel(tokenKey)}
        </p>
        <SelectionRow
          value={valueToText(value) || 'system'}
          options={options}
          onPick={(next) =>
            next === 'system' && tokenKey === 'theme'
              ? store.getState().stageTokenRemove(tokenKey)
              : store.getState().stageToken(tokenKey, next)
          }
        />
      </div>
    );
  }

  return (
    <div className="space-y-1.5 rounded-lg border border-white/5 bg-white/[0.02] px-3 py-2">
      <div className="flex items-center justify-between gap-2">
        <label
          htmlFor={`token-${tokenKey}`}
          className="text-[10px] font-mono uppercase tracking-wider text-gray-500"
        >
          {tokenLabel(tokenKey)}
        </label>
        {isNativeColor ? (
          <label
            className="relative size-4 shrink-0 cursor-pointer overflow-hidden rounded-full border border-white/25"
            style={{ backgroundColor: text.trim() }}
            title="Pick a colour"
          >
            <input
              type="color"
              className="absolute size-8 cursor-pointer opacity-0"
              value={text.trim().slice(0, 7)}
              onChange={(e) => onChangeHex(e.target.value)}
            />
          </label>
        ) : null}
      </div>
      <input
        id={`token-${tokenKey}`}
        value={text}
        placeholder={
          TOKEN_PLACEHOLDERS[tokenKey] ?? 'Template default — type to set'
        }
        spellCheck={false}
        onChange={(e) => commit(e.target.value)}
        className={`w-full rounded-md border bg-white/[0.03] px-2.5 py-1.5 font-mono text-[11.5px] text-gray-200 outline-none focus:border-[#00D4FF]/50 ${
          problem ? 'border-amber-400/40' : 'border-white/10'
        }`}
      />
      <p className={`text-[10px] leading-snug ${problem ? 'text-amber-300/80' : 'text-gray-600'}`}>
        {problem ?? (value === undefined ? 'Template default' : `--portal-${kebabOf(tokenKey)}`)}
      </p>
    </div>
  );
}

function SelectionRow({
  value,
  options,
  onPick,
}: {
  value: string;
  options: string[];
  onPick: (next: string) => void;
}) {
  return (
    <div className="flex gap-1">
      {options.map((option) => (
        <button
          key={option}
          type="button"
          onClick={() => onPick(option)}
          className={`flex-1 rounded-md px-2 py-1 text-[11px] font-medium transition-colors ${
            value === option
              ? 'bg-[#00D4FF]/15 text-[#00D4FF] ring-1 ring-inset ring-[#00D4FF]/40'
              : 'text-gray-500 hover:bg-white/5 hover:text-gray-300'
          }`}
        >
          {option}
        </button>
      ))}
    </div>
  );
}

function WorkspaceInspector() {
  const document_ = store((s) => s.document);

  return (
    <div className="space-y-5">
      <ScopeHeader
        title="Workspace Design"
        subtitle="The identity of your provisioned OS"
      />

      <TemplateBanner templateId={document_?.templateId ?? null} />

      {TOKEN_GROUPS.map((group) => (
        <section key={group.label} className="space-y-2">
          <h3 className="text-[10px] font-mono uppercase tracking-wider text-gray-500">
            {group.label}
          </h3>
          <div className="space-y-1.5">
            {group.keys.map((key) => (
              <TokenControl key={key} tokenKey={key} />
            ))}
          </div>
        </section>
      ))}

      <div className="rounded-xl border border-white/5 bg-white/[0.02] p-3.5">
        <p className="flex items-start gap-2 text-[11px] leading-relaxed text-gray-500">
          <ShieldCheck className="mt-0.5 size-3.5 shrink-0 text-[#00D4FF]" />
          Values autosave to the workspace draft. Live pages keep serving the
          published revision until you publish again.
        </p>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// PAGE SCOPE
// ─────────────────────────────────────────────────────────────────────────────

function PageInspector({ pageKey }: { pageKey: string | null }) {
  const document_ = store((s) => s.document);

  if (!pageKey) {
    return (
      <div className="space-y-4">
        <ScopeHeader title="Page" subtitle="Nothing framed yet" />
        <p className="text-[12px] leading-relaxed text-gray-500">
          Choose a page from the Workspace Structure to begin.
        </p>
      </div>
    );
  }

  const sectionCount = (document_?.pageLayouts?.[pageKey] ?? []).length;

  return (
    <div className="space-y-5">
      <ScopeHeader title={pageKey} subtitle="Page presentation" />

      <section className="space-y-3">
        <h3 className="text-[10px] font-mono uppercase tracking-wider text-gray-500">
          Structure
        </h3>
        <InfoRow label="Sections" value={String(sectionCount)} />
        <InfoRow label="Route" value={`/portal/${pageKey}`} mono />
        <InfoRow
          label="SEO"
          value={
            document_?.seo?.[pageKey]?.title
              ? document_.seo[pageKey]?.title as string
              : 'Not customised'
          }
        />
      </section>

      <div className="rounded-xl border border-white/5 bg-white/[0.02] p-3.5">
        <p className="text-[12px] leading-relaxed text-gray-500">
          Page-level background, section spacing and responsive rules arrive
          with the Layout phase. Character-level detail lives on each section.
        </p>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// COMPONENT SCOPE
// ─────────────────────────────────────────────────────────────────────────────

function ComponentInspector({
  selection,
}: {
  selection: { pageKey: string | null; instanceId: string | null };
}) {
  const projectId = store((s) => s.meta?.projectId);
  const document_ = store((s) => s.document);
  const manifest = useManifest(projectId ?? '');

  let node: IRNode | null = null;
  if (
    manifest.data &&
    document_ &&
    selection.pageKey &&
    selection.instanceId
  ) {
    const ir = buildPageIR(manifest.data, document_, selection.pageKey);
    node = ir.nodes.find((n) => n.instanceId === selection.instanceId) ?? null;
  }

  if (!selection.instanceId) {
    return (
      <div className="space-y-4">
        <ScopeHeader title="Section" subtitle="No selection" />
        <p className="text-[12px] leading-relaxed text-gray-500">
          Select a section on the canvas or in the Layers list to customise it.
        </p>
      </div>
    );
  }

  if (!node) {
    return (
      <div className="space-y-4">
        <ScopeHeader title="Section" subtitle={selection.instanceId} />
        <div className="rounded-xl border border-amber-400/15 bg-amber-400/[0.04] p-3.5">
          <p className="text-[12px] leading-relaxed text-gray-400">
            This section is no longer part of the current draft (it may have
            just been removed). The inspector will follow the reloaded draft.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <ScopeHeader
        title={node.componentName}
        subtitle={node.contractKnown ? node.category.replace(/_/g, ' ') : 'Unknown contract'}
      />

      {!node.contractKnown ? (
        <div className="rounded-xl border border-amber-400/15 bg-amber-400/[0.04] p-3.5">
          <p className="text-[12px] leading-relaxed text-gray-400">
            <Lock className="mr-1.5 inline size-3.5 text-amber-300" />
            This component is not declared in the active workspace contract, so
            no controls can be offered for it.
          </p>
        </div>
      ) : null}

      {node.protectedNotice ? (
        <div className="rounded-xl border border-[#00D4FF]/15 bg-[#00D4FF]/[0.04] p-3.5">
          <p className="text-[12px] leading-relaxed text-gray-300">
            <Lock className="mr-1.5 inline size-3.5 text-[#00D4FF]" />
            {node.protectedNotice}
          </p>
        </div>
      ) : null}

      {node.contentFields.length > 0 ? (
        <FieldGroup
          icon={<Type className="size-3" />}
          title="Content"
          node={node}
          pageKey={selection.pageKey ?? ''}
          fields={node.contentFields}
        />
      ) : null}

      {node.appearanceFields.length > 0 ? (
        <FieldGroup
          icon={<Palette className="size-3" />}
          title="Appearance"
          node={node}
          pageKey={selection.pageKey ?? ''}
          fields={node.appearanceFields}
        />
      ) : null}

      {node.settingFields.length > 0 ? (
        <FieldGroup
          icon={<Settings2 className="size-3" />}
          title="Settings"
          node={node}
          pageKey={selection.pageKey ?? ''}
          fields={node.settingFields}
        />
      ) : null}

      {node.contentFields.length === 0 &&
      node.appearanceFields.length === 0 &&
      node.settingFields.length === 0 &&
      node.contractKnown ? (
        <p className="text-[12px] leading-relaxed text-gray-500">
          This section is fully managed by GN-Apex.
        </p>
      ) : null}
    </div>
  );
}

function FieldGroup({
  icon,
  title,
  node,
  pageKey,
  fields,
}: {
  icon: React.ReactNode;
  title: string;
  node: IRNode;
  pageKey: string;
  fields: IRNode['contentFields'];
}) {
  return (
    <section className="space-y-2.5">
      <h3 className="flex items-center gap-1.5 text-[10px] font-mono uppercase tracking-wider text-gray-500">
        {icon}
        {title}
      </h3>
      {fields.map((field) => (
        <FieldControl
          key={field.key}
          field={field}
          value={node.props[field.key]}
          pageKey={pageKey}
          instanceId={node.instanceId}
        />
      ))}
    </section>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// SHARED BITS
// ─────────────────────────────────────────────────────────────────────────────

function ScopeHeader({ title, subtitle }: { title: string; subtitle: string }) {
  return (
    <header className="space-y-0.5">
      <h2 className="truncate text-[15px] font-semibold tracking-tight text-gray-100">
        {title}
      </h2>
      <p className="text-[11px] font-mono uppercase tracking-wider text-gray-600">
        {subtitle}
      </p>
    </header>
  );
}

function InfoRow({
  label,
  value,
  mono,
}: {
  label: string;
  value: string;
  mono?: boolean;
}) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-lg border border-white/5 bg-white/[0.02] px-3 py-2">
      <span className="text-[11px] text-gray-500">{label}</span>
      <span
        className={`truncate text-[11px] text-gray-300 ${mono ? 'font-mono' : ''}`}
      >
        {value}
      </span>
    </div>
  );
}
