// studio/src/components/gnapex-studio/inspector/field-controls.tsx
//
// SCHEMA-DRIVEN FIELD CONTROLS.
//
// The inspector is generated from the backend manifest's `fields` array — the
// same contract the portal components own. Nothing here is inferred from CSS
// or DOM; a field exists because the component contract says so.
//
// Every control commits through `stageProps`, which stages a typed
// `node.updateProps` operation that autosave persists with a revision guard.

'use client';

import { useRef, useState } from 'react';
import { List, Lock } from 'lucide-react';

import type { ManifestField } from '@/lib/contract';
import { store } from '@/lib/gnapex-studio/store';

function Label({ field }: { field: ManifestField }) {
  return (
    <label
      htmlFor={`field-${field.key}`}
      className="text-[10px] font-mono uppercase tracking-wider text-gray-500"
    >
      {field.label}
    </label>
  );
}

/** Locks fields that are structurally fragile for v1 clients. */
function LockedField({ field }: { field: ManifestField }) {
  return (
    <div className="rounded-lg border border-white/5 bg-white/[0.02] p-3">
      <div className="flex items-center justify-between gap-2">
        <span className="text-[10px] font-mono uppercase tracking-wider text-gray-500">
          {field.label}
        </span>
        <Lock className="size-3 text-gray-600" />
      </div>
      <p className="mt-1 text-[11px] leading-relaxed text-gray-600">
        Structured editing for {field.type.toLowerCase()} fields arrives with the
        full Inspector release.
      </p>
    </div>
  );
}

export function FieldControl({
  field,
  value,
  pageKey,
  instanceId,
}: {
  field: ManifestField;
  value: unknown;
  pageKey: string;
  instanceId: string;
}) {
  // Local text state keeps typing instant; commits debounce into the store.
  // Incoming authoritative values sync during render (the React-recommended
  // "adjust state when props change" pattern) — no cascading effect.
  const [text, setText] = useState(valueToString(value));
  const [lastValue, setLastValue] = useState(value);
  const commitTimer = useRef<number | undefined>(undefined);
  if (value !== lastValue) {
    setLastValue(value);
    setText(valueToString(value));
  }

  function commitString(next: string) {
    setText(next);
    window.clearTimeout(commitTimer.current);
    commitTimer.current = window.setTimeout(() => {
      store.getState().stageProps(pageKey, instanceId, { [field.key]: next });
    }, 350);
  }

  switch (field.type) {
    case 'TEXT':
      return (
        <div className="space-y-1.5">
          <Label field={field} />
          <input
            id={`field-${field.key}`}
            value={text}
            onChange={(e) => commitString(e.target.value)}
            className="w-full rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2 text-[13px] text-gray-200 outline-none focus:border-[#00D4FF]/50"
          />
          {field.helpText ? (
            <p className="text-[10px] leading-relaxed text-gray-600">{field.helpText}</p>
          ) : null}
        </div>
      );

    case 'TEXT_LONG':
    case 'RICH_TEXT':
      return (
        <div className="space-y-1.5">
          <Label field={field} />
          {field.type === 'RICH_TEXT' ? (
            <p className="text-[10px] text-gray-600">Plain-text editing — rich formatting is contract-constrained.</p>
          ) : null}
          <textarea
            id={`field-${field.key}`}
            value={text}
            rows={3}
            onChange={(e) => commitString(e.target.value)}
            className="w-full resize-none rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2 text-[13px] leading-relaxed text-gray-200 outline-none focus:border-[#00D4FF]/50"
          />
        </div>
      );

    case 'NUMBER': {
      const num = typeof value === 'number' ? value : Number(value) || 0;
      return (
        <div className="space-y-1.5">
          <Label field={field} />
          <input
            id={`field-${field.key}`}
            type="number"
            value={num}
            onChange={(e) => {
              const next = Number(e.target.value);
              if (!Number.isNaN(next)) {
                store.getState().stageProps(pageKey, instanceId, { [field.key]: next });
              }
            }}
            className="w-full rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2 text-[13px] text-gray-200 outline-none focus:border-[#00D4FF]/50"
          />
        </div>
      );
    }

    case 'BOOLEAN':
      return (
        <div className="flex items-center justify-between gap-3 rounded-lg border border-white/10 bg-white/[0.02] px-3 py-2.5">
          <span className="text-[12px] text-gray-300">{field.label}</span>
          <button
            type="button"
            role="switch"
            aria-checked={value === true}
            onClick={() =>
              store.getState().stageProps(pageKey, instanceId, {
                [field.key]: value !== true,
              })
            }
            className={`relative h-5 w-9 shrink-0 rounded-full transition-colors ${
              value === true ? 'bg-[#00D4FF]' : 'bg-white/15'
            }`}
          >
            <span
              className={`absolute top-0.5 size-4 rounded-full bg-white transition-transform ${
                value === true ? 'translate-x-4' : 'translate-x-0.5'
              }`}
            />
          </button>
        </div>
      );

    case 'SELECT': {
      const text2 = typeof value === 'string' ? value : String(value ?? '');
      return (
        <div className="space-y-1.5">
          <Label field={field} />
          <select
            id={`field-${field.key}`}
            value={text2}
            onChange={(e) =>
              store.getState().stageProps(pageKey, instanceId, { [field.key]: e.target.value })
            }
            className="w-full rounded-lg border border-white/10 bg-[#0B0D14] px-3 py-2 text-[13px] text-gray-200 outline-none focus:border-[#00D4FF]/50"
          >
            {field.options.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
      );
    }

    case 'MULTI_SELECT': {
      const selected = Array.isArray(value) ? value.map(String) : [];
      return (
        <div className="space-y-1.5">
          <Label field={field} />
          <div className="flex flex-wrap gap-1.5">
            {field.options.map((option) => {
              const active = selected.includes(option.value);
              return (
                <button
                  key={option.value}
                  type="button"
                  onClick={() => {
                    const next = active
                      ? selected.filter((v) => v !== option.value)
                      : [...selected, option.value];
                    store.getState().stageProps(pageKey, instanceId, { [field.key]: next });
                  }}
                  className={`rounded-md border px-2 py-1 text-[11px] transition-colors ${
                    active
                      ? 'border-[#00D4FF]/60 bg-[#00D4FF]/10 text-[#00D4FF]'
                      : 'border-white/10 text-gray-400 hover:border-white/20'
                  }`}
                >
                  {option.label}
                </button>
              );
            })}
          </div>
        </div>
      );
    }

    case 'COLOR':
      return (
        <div className="space-y-1.5">
          <Label field={field} />
          <div className="flex items-center gap-2">
            <input
              id={`field-${field.key}`}
              type="color"
              value={isValidHex(text) ? text : '#ffffff'}
              onChange={(e) =>
                store.getState().stageProps(pageKey, instanceId, { [field.key]: e.target.value })
              }
              className="size-8 shrink-0 cursor-pointer rounded-md border border-white/10 bg-transparent"
            />
            <input
              value={text}
              onChange={(e) => commitString(e.target.value)}
              className="w-full rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2 font-mono text-[12px] text-gray-200 outline-none focus:border-[#00D4FF]/50"
            />
          </div>
        </div>
      );

    case 'IMAGE':
    case 'URL':
    case 'DATE':
      return (
        <div className="space-y-1.5">
          <Label field={field} />
          <input
            id={`field-${field.key}`}
            value={text}
            type={field.type === 'DATE' ? 'date' : 'text'}
            placeholder={field.type === 'IMAGE' ? 'Image URL' : field.type === 'URL' ? 'https://…' : undefined}
            onChange={(e) => commitString(e.target.value)}
            className="w-full rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2 text-[13px] text-gray-200 outline-none focus:border-[#00D4FF]/50"
          />
        </div>
      );

    case 'LIST':
    case 'KEY_VALUE':
    case 'REFERENCE': {
      const count = Array.isArray(value) ? value.length : value ? 1 : 0;
      return (
        <div className="rounded-lg border border-white/5 bg-white/[0.02] p-3">
          <div className="flex items-center justify-between gap-2">
            <span className="text-[10px] font-mono uppercase tracking-wider text-gray-500">
              {field.label}
            </span>
            <span className="flex items-center gap-1 text-[10px] font-mono text-[#00D4FF]">
              <List className="size-3" />
              {count} item{count === 1 ? '' : 's'}
            </span>
          </div>
          <p className="mt-1 text-[11px] leading-relaxed text-gray-600">
            Structured list editing arrives with the full Inspector release.
          </p>
        </div>
      );
    }

    default:
      return <LockedField field={field} />;
  }
}

function valueToString(value: unknown): string {
  if (value === null || value === undefined) return '';
  if (typeof value === 'string') return value;
  if (typeof value === 'number' || typeof value === 'boolean') return String(value);
  return '';
}

function isValidHex(text: string): boolean {
  return /^#[0-9a-fA-F]{3,8}$/.test(text);
}
