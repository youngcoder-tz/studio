// studio/src/components/gnapex-studio/shell/layers-panel.tsx
//
// THE LAYERS LIST.
//
// The ordered document structure of the framed page, expressed semantically —
// component names from the contract, never raw div nesting. Selection syncs
// in both directions with the live canvas through the bridge.

'use client';

import { Blocks, ShieldAlert } from 'lucide-react';

import type { StudioManifest, WorkspaceDocument } from '@/lib/contract';
import { store } from '@/lib/gnapex-studio/store';
import { buildPageIR } from '@/lib/gnapex-studio/visual-ir';

export function LayersPanel({
  pageKey,
  manifest,
  document: document_,
}: {
  pageKey: string;
  manifest: StudioManifest;
  document: WorkspaceDocument;
}) {
  const selection = store((s) => s.selection);
  const hoverInstanceId = store((s) => s.hoverInstanceId);
  const selectInstance = store((s) => s.selectInstance);
  const setHover = store((s) => s.setHover);

  const ir = buildPageIR(manifest, document_, pageKey);

  if (ir.nodes.length === 0) {
    return (
      <div className="flex flex-col items-center gap-2 px-4 py-10 text-center">
        <Blocks className="size-6 text-gray-700" />
        <p className="text-[12px] leading-relaxed text-gray-600">
          This page has no sections in the draft yet.
        </p>
      </div>
    );
  }

  return (
    <ul className="space-y-0.5 pb-8" role="list">
      {ir.nodes.map((node) => {
        const active = selection.instanceId === node.instanceId;
        const hovered = hoverInstanceId === node.instanceId;
        return (
          <li key={node.orderKey}>
            <button
              type="button"
              onClick={() => selectInstance(pageKey, node.instanceId)}
              onMouseEnter={() => setHover(node.instanceId)}
              onMouseLeave={() => setHover(null)}
              className={`flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-left transition-colors ${
                active
                  ? 'bg-[#00D4FF]/10 text-[#00D4FF]'
                  : hovered
                    ? 'bg-white/[0.05] text-gray-200'
                    : 'text-gray-400 hover:bg-white/[0.04] hover:text-gray-200'
              }`}
            >
              <Blocks
                className={`size-3.5 shrink-0 ${
                  active ? 'text-[#00D4FF]' : 'text-gray-600'
                }`}
              />
              <span className="flex-1 truncate text-[12px]">
                {node.componentName}
              </span>
              {!node.contractKnown ? (
                <ShieldAlert
                  className="size-3 shrink-0 text-amber-400/70"
                  aria-label="Component not in contract"
                />
              ) : (
                <span className="shrink-0 text-[9px] font-mono uppercase tracking-wider text-gray-700">
                  {node.category}
                </span>
              )}
            </button>
          </li>
        );
      })}
    </ul>
  );
}
