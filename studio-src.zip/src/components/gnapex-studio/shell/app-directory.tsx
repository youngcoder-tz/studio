// studio/src/components/gnapex-studio/shell/app-directory.tsx
//
// THE WORKSPACE STRUCTURE.
//
// The application directory, not a generic "Pages" list. It is derived from
// the workspace contract's page catalog (grouped per mode) plus the virtual
// "Workspace Design" entry. The client navigates their provisioned OS the way
// they think about it: areas → pages.

'use client';

import { Dot, PencilRuler } from 'lucide-react';

import type { StudioManifest, WorkspaceDocument } from '@/lib/contract';
import { store } from '@/lib/gnapex-studio/store';
import { buildDirectory } from '@/lib/gnapex-studio/visual-ir';

export function AppDirectory({
  manifest,
  document: document_,
}: {
  manifest: StudioManifest;
  document: WorkspaceDocument;
}) {
  const selection = store((s) => s.selection);
  const selectPage = store((s) => s.selectPage);
  const selectWorkspace = store((s) => s.selectWorkspace);

  const groups = buildDirectory(manifest, document_);

  return (
    <nav aria-label="Workspace structure" className="space-y-4 pb-8">
      {groups.map((group) => (
        <section key={group.area.key}>
          {group.area.design ? (
            <button
              type="button"
              onClick={selectWorkspace}
              className={`group flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left transition-colors ${
                selection.scope === 'workspace'
                  ? 'bg-[#00D4FF]/10 text-[#00D4FF]'
                  : 'text-gray-300 hover:bg-white/[0.04]'
              }`}
            >
              <PencilRuler
                className={`size-3.5 shrink-0 ${
                  selection.scope === 'workspace'
                    ? 'text-[#00D4FF]'
                    : 'text-gray-500 group-hover:text-gray-300'
                }`}
              />
              <span className="text-[13px] font-medium">Workspace Design</span>
            </button>
          ) : null}

          {!group.area.design ? (
            <>
              <h3 className="mb-1 px-2.5 pt-2 text-[10px] font-mono font-semibold uppercase tracking-wider text-gray-600">
                {group.area.label}
              </h3>
              <ul className="space-y-0.5">
                {group.entries.map((entry) => {
                  const active =
                    selection.pageKey === entry.page.key &&
                    selection.scope !== 'workspace';
                  return (
                    <li key={entry.page.key}>
                      <button
                        type="button"
                        onClick={() => selectPage(entry.page.key)}
                        className={`flex w-full items-center justify-between gap-2 rounded-lg px-2.5 py-1.5 text-left transition-colors ${
                          active
                            ? 'bg-[#00D4FF]/10 text-[#00D4FF]'
                            : 'text-gray-400 hover:bg-white/[0.04] hover:text-gray-200'
                        }`}
                      >
                        <span className="truncate text-[13px]">
                          {entry.page.label}
                        </span>
                        <span className="flex shrink-0 items-center gap-1">
                          {entry.page.required ? (
                            <span
                              title="Contract-required page"
                              className="text-[9px] font-mono uppercase tracking-wider text-gray-600"
                            >
                              req
                            </span>
                          ) : null}
                          <Dot
                            className={`size-4 ${
                              entry.provisioned
                                ? active
                                  ? 'text-[#00D4FF]'
                                  : 'text-gray-600'
                                : 'text-gray-800'
                            }`}
                          />
                        </span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            </>
          ) : null}
        </section>
      ))}
    </nav>
  );
}
