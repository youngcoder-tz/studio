// studio/src/components/gnapex-studio/shell/status-bar.tsx
//
// THE STATUS BAR.
//
// Persistent honest state: bridge health, framed page, draft revision and
// save state. Nothing here is aspirational — every chip reflects a real
// store value.

'use client';

import { Check, CircleAlert, CloudUpload, Loader } from 'lucide-react';

import { store } from '@/lib/gnapex-studio/store';

export function StatusBar() {
  const bridgeStatus = store((s) => s.bridgeStatus);
  const bridgeError = store((s) => s.bridgeError);
  const previewPageKey = store((s) => s.previewPageKey);
  const document_ = store((s) => s.document);
  const pendingOps = store((s) => s.pendingOps);
  const viewport = store((s) => s.viewport);

  const saving = pendingOps.length > 0;
  const savedAt = document_?.lastSavedAt
    ? new Date(document_.lastSavedAt).toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
      })
    : null;

  return (
    <footer className="flex h-8 shrink-0 items-center justify-between gap-6 border-t border-white/10 bg-[#0B0D14] px-4 font-mono text-[10px] uppercase tracking-wider">
      <div className="flex items-center gap-4 text-gray-500">
        <span
          className={
            bridgeStatus === 'active'
              ? 'flex items-center gap-1.5 text-[#00D4FF]'
              : bridgeStatus === 'connecting'
                ? 'flex items-center gap-1.5 text-amber-300'
                : 'flex items-center gap-1.5 text-red-400'
          }
          title={bridgeError ?? undefined}
        >
          {bridgeStatus === 'connecting' ? (
            <Loader className="size-3 animate-spin" />
          ) : bridgeStatus === 'active' ? (
            <Check className="size-3" />
          ) : (
            <CircleAlert className="size-3" />
          )}
          {bridgeStatus === 'active' ? 'bridge live' : bridgeStatus}
        </span>
        {previewPageKey ? <span>framed: {previewPageKey}</span> : null}
        <span>viewport: {viewport}</span>
      </div>
      <div className="flex items-center gap-4 text-gray-500">
        {document_ ? <span>draft r{document_.draftRevision}</span> : null}
        {saving ? (
          <span className="flex items-center gap-1.5 text-amber-300">
            <Loader className="size-3 animate-spin" />
            saving…
          </span>
        ) : savedAt ? (
          <span className="flex items-center gap-1.5 text-gray-400">
            <CloudUpload className="size-3" />
            draft saved {savedAt}
          </span>
        ) : document_ ? (
          <span className="flex items-center gap-1.5">draft loaded</span>
        ) : null}
      </div>
    </footer>
  );
}
