// studio/src/components/gnapex-studio/shell/studio-shell.tsx
// THE GN-APEX SHELL.

'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

import { store } from '@/lib/gnapex-studio/store';
import { useAutosave } from '@/hooks/gnapex-studio/use-autosave';

import { TopBar } from './top-bar';
import { LayersPanel } from './layers-panel';
import { AppDirectory } from './app-directory';
import { PreviewFrame } from '@/components/gnapex-studio/canvas/preview-frame';
import { InspectorRoot } from '@/components/gnapex-studio/inspector/inspector-root';
import { StatusBar } from './status-bar';
import { CommandPalette } from '@/components/gnapex-studio/command-palette/command-palette';
import { ShortcutsModal } from '@/components/gnapex-studio/overlays/shortcuts-modal';
import { CanvasContextMenu } from '@/components/gnapex-studio/context-menu/context-menu';

function useGlobalShortcuts(setShortcutsOpen: (v: boolean | ((prev: boolean) => boolean)) => void) {
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === '/') {
        e.preventDefault();
        setShortcutsOpen((v) => !v);
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [setShortcutsOpen]);
}

export function StudioShell({
  projectId,
  manifest,
  document,
  previewToken,
  previewOrigin,
  framedPageKey,
}: {
  projectId: string;
  manifest: any;
  document: any;
  previewToken: string | null;
  previewOrigin: string;
  framedPageKey: string;
}) {
  const [leftCollapsed, setLeftCollapsed] = useState(false);
  const [rightCollapsed, setRightCollapsed] = useState(false);
  const [commandOpen, setCommandOpen] = useState(false);
  const [shortcutsOpen, setShortcutsOpen] = useState(false);
  const explorerTab = store((s) => s.explorerTab);
  useGlobalShortcuts(setShortcutsOpen);

  useAutosave(projectId, !!document);

  return (
    <div className="flex h-dvh flex-col bg-[#090A0F] text-gray-100">
      <TopBar manifest={manifest} />
      <div className="flex min-h-0 flex-1">
        {!leftCollapsed && (
          <motion.aside
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.25 }}
            className="flex w-[280px] flex-col border-r border-white/5"
          >
            {explorerTab === 'layers' ? (
              <LayersPanel
                pageKey={framedPageKey}
                manifest={manifest}
                document={document}
              />
            ) : (
              <AppDirectory manifest={manifest} document={document} />
            )}
          </motion.aside>
        )}
        <main className="relative flex min-w-0 flex-1 flex-col" data-gnapex-canvas>
          <PreviewFrame
            projectId={projectId}
            pageKey={framedPageKey}
            previewToken={previewToken}
            resolvedOrigin={previewOrigin}
          />
        </main>
        {!rightCollapsed && (
          <motion.aside
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.25 }}
            className="flex w-[320px] flex-col border-l border-white/5"
          >
            <InspectorRoot />
          </motion.aside>
        )}
      </div>
      <StatusBar />
      <CommandPalette open={commandOpen} onOpenChange={setCommandOpen} />
      <ShortcutsModal open={shortcutsOpen} onClose={() => setShortcutsOpen(false)} />
      <CanvasContextMenu />
    </div>
  );
}
