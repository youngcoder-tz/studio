// studio/src/components/gnapex-studio/shell/top-bar.tsx

'use client';

import { Keyboard } from 'lucide-react';
import { useState } from 'react';
import {
  ChevronRight,
  Download,
  LayoutTemplate,
  Monitor,
  Redo2,
  ShieldQuestion,
  Smartphone,
  TabletSmartphone,
  Undo2,
} from 'lucide-react';
import { toast } from 'sonner';

import { publishWorkspace } from '@/lib/api/workspace';
import type { WorkspaceMode } from '@/lib/contract';
import { store } from '@/lib/gnapex-studio/store';
import { MODE_OS_NAMES, buildPageIR, normalizePageCatalog } from '@/lib/gnapex-studio/visual-ir';
import type { StudioManifest } from '@/lib/contract';
import { VIEWPORTS, type ViewportKey } from '@/lib/gnapex-studio/types';

function usePublishAction() {
  const meta = store((s) => s.meta);
  const [confirming, setConfirming] = useState(false);
  const [isPending, setPending] = useState(false);

  return {
    confirming,
    isPending,
    confirm: () => setConfirming(true),
    cancel: () => setConfirming(false),
    async run() {
      if (!meta) return;
      setPending(true);
      try {
        const result = await publishWorkspace(
          meta.projectId,
          'Published from the GN-Apex Studio',
        );
        toast.success('Workspace published', {
          description: `Live revision ${result.liveRevision} is now serving the portal.`,
        });
        setConfirming(false);
      } catch (error) {
        toast.error('Publish failed', {
          description: error instanceof Error ? error.message : 'Unknown error',
        });
        setConfirming(false);
      } finally {
        setPending(false);
      }
    },
  };
}

function useBreadcrumb(manifest: StudioManifest | null): string[] {
  const meta = store((s) => s.meta);
  const selection = store((s) => s.selection);
  const document_ = store((s) => s.document);

  if (!meta) return [];
  const os = MODE_OS_NAMES[meta.workspaceMode as WorkspaceMode] ?? meta.workspaceMode;
  if (selection.scope === 'workspace') return [os, 'Workspace Design'];
  if (!selection.pageKey || !document_ || !manifest) return [os];

  const page = normalizePageCatalog(manifest.pageCatalog).find(
    (p) => p.key === selection.pageKey,
  );
  const crumbs = [os, page?.label ?? selection.pageKey];

  if (selection.scope === 'component' && selection.instanceId) {
    const ir = buildPageIR(manifest, document_, selection.pageKey);
    const node = ir.nodes.find((n) => n.instanceId === selection.instanceId);
    if (node) crumbs.push(node.componentName);
  }
  return crumbs;
}

/** How template keys read in the chip, first-class template first. */
const TEMPLATE_CHIP_NAMES: Record<string, string> = {
  'edu-os-enterprise': 'Edu OS — Enterprise',
};

function useTemplateId(): string | null {
  const document_ = store((s) => s.document);
  return document_?.templateId ?? null;
}

export function TopBar({ manifest }: { manifest: StudioManifest | null }) {
  const meta = store((s) => s.meta);
  const viewport = store((s) => s.viewport);
  const setViewport = store((s) => s.setViewport);
  const templateId = useTemplateId();

  const breadcrumb = useBreadcrumb(manifest);
  const publish = usePublishAction();

  if (!meta) {
    return <div className="h-14 shrink-0 border-b border-white/10" />;
  }

  return (
    <header className="relative flex h-14 shrink-0 items-center gap-4 border-b border-white/10 bg-[#0B0D14] px-4">
      <div className="flex min-w-0 items-center gap-3">
        <span className="flex size-7 shrink-0 items-center justify-center rounded-md bg-[#00D4FF] font-black text-[#090A0F]">
          A
        </span>
        <div className="min-w-0">
          <p className="text-[11px] font-mono font-semibold uppercase tracking-wider text-[#00D4FF]">
            GN-Apex Studio
          </p>
          <p className="truncate text-[12px] text-gray-500">
            {MODE_OS_NAMES[meta.workspaceMode as WorkspaceMode] ??
              meta.workspaceMode} ·{' '}
            <span className="text-gray-400">{meta.projectName}</span>
          </p>
        </div>
      </div>

      <div className="flex min-w-0 flex-1 items-center justify-center gap-1.5 font-mono text-[11px] uppercase tracking-wider text-gray-500">
        {breadcrumb.map((crumb, index) => (
          <span key={`${crumb}-${index}`} className="flex items-center gap-1.5">
            {index > 0 ? <ChevronRight className="size-3 text-gray-700" /> : null}
            <span className={index === breadcrumb.length - 1 ? 'text-gray-200' : undefined}>
              {crumb}
            </span>
          </span>
        ))}
      </div>

      {/* The selected template, never more than one glance away */}
      {templateId ? (
        <button
          type="button"
          title="The template this workspace was commissioned with — its UI/UX is customised in the right panel"
          onClick={() => store.getState().selectWorkspace()}
          className="hidden shrink-0 items-center gap-1.5 rounded-full border border-[#00D4FF]/25 bg-[#00D4FF]/[0.06] px-2.5 py-1 text-[10px] font-mono uppercase tracking-wider text-[#00D4FF] transition-colors hover:bg-[#00D4FF]/15 lg:flex"
        >
          <LayoutTemplate className="size-3" />
          {(TEMPLATE_CHIP_NAMES[templateId] ??
            templateId.replace(/-/g, ' '))} ·
          <span className="text-gray-400">customize UI/UX</span>
        </button>
      ) : null}

      <div className="flex items-center gap-2">
        <button
          type="button"
          title="Keyboard shortcuts (⌘/)"
          onClick={() => {
            try {
              window.dispatchEvent(new KeyboardEvent('keydown', { key: '/', metaKey: true }));
            } catch {}
          }}
          className="rounded-lg border border-white/10 px-2 py-1.5 text-gray-500 hover:text-gray-300"
        >
          <Keyboard className="size-3.5" />
        </button>
        <button
          type="button"
          onClick={() => publish.confirm()}
          disabled={publish.isPending}
          className="flex items-center gap-1.5 rounded-lg bg-[#00D4FF] px-3 py-1.5 text-[12px] font-semibold text-[#090A0F] transition-opacity hover:opacity-90 disabled:opacity-50"
        >
          {publish.isPending ? <Download className="size-3.5 animate-pulse" /> : null}
          Publish
        </button>
      </div>

      {publish.confirming ? (
        <div className="absolute right-4 top-14 z-30 w-[320px] rounded-xl border border-white/10 bg-[#0B0D14]/95 p-3 shadow-2xl backdrop-blur-xl">
          <div className="flex items-start gap-2">
            <ShieldQuestion className="mt-0.5 size-4 text-[#00D4FF]" />
            <div className="flex-1">
              <p className="text-[12px] font-semibold text-gray-100">Publish workspace</p>
              <p className="mt-1 text-[11px] leading-relaxed text-gray-500">
                Push the current draft to the live portal. Visitors will see these changes.
              </p>
              <div className="mt-3 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => publish.cancel()}
                  className="rounded-lg px-2 py-1 text-[11px] text-gray-500 hover:text-gray-300"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => publish.run()}
                  disabled={publish.isPending}
                  className="rounded-lg bg-[#00D4FF] px-3 py-1.5 text-[12px] font-semibold text-[#090A0F] hover:opacity-90 disabled:opacity-50"
                >
                  Publish now
                </button>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </header>
  );
}
