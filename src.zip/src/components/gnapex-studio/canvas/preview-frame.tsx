// studio/src/components/gnapex-studio/canvas/preview-frame.tsx
//
// THE LIVE CANVAS.
//
// Frames the real provisioned Next.js ERP portal through the typed bridge.
// It uses the dynamic origin resolved from the backend, with full sandbox
// mock data streamed into the frame during authoring.

"use client";

import { useEffect, useMemo, useRef } from "react";
import { Loader2, MousePointerClick, PlugZap } from "lucide-react";

import { usePreviewBridge } from "@/hooks/gnapex-studio/use-preview-bridge";
import { store } from "@/lib/gnapex-studio/store";
import { previewPathFor } from "@/lib/preview";
import { VIEWPORTS } from "@/lib/gnapex-studio/types";
import { SelectionOverlay } from "./selection-overlay";
import { FloatingToolbar } from "./floating-toolbar";
import { ZoomControls } from "./zoom-controls";

export function PreviewFrame({
  projectId,
  pageKey,
  previewToken,
  resolvedOrigin,
}: {
  projectId: string;
  pageKey: string;
  previewToken: string | null;
  /** Absolute origin dynamically derived from backend template runtime or window origin */
  resolvedOrigin: string;
}) {
  const frameRef = useRef<HTMLIFrameElement | null>(null);
  const viewport = store((s) => s.viewport);
  const bridgeStatus = store((s) => s.bridgeStatus);
  const setBridgeStatus = store((s) => s.setBridgeStatus);

  usePreviewBridge({
    projectId,
    pageKey,
    previewOrigin: resolvedOrigin,
    frameRef,
    enabled: true,
  });

  const frameSrc = useMemo(() => {
    const path = previewPathFor(pageKey);
    const params = new URLSearchParams();
    params.set("preview", "draft");
    params.set("_preview", "true");
    params.set("projectId", projectId);
    params.set("_studio", "1");

    if (previewToken) {
      params.set("previewKey", previewToken);
    }

    const currentOrigin =
      typeof window !== "undefined" ? window.location.origin : "";
    if (currentOrigin) {
      params.set("studioOrigin", currentOrigin);
    }

    const base = resolvedOrigin ? resolvedOrigin.replace(/\/$/, "") : "";
    return `${base}${path}?${params.toString()}`;
  }, [pageKey, previewToken, projectId, resolvedOrigin]);

  // Reset bridge status when the frame target changes
  useEffect(() => {
    setBridgeStatus("connecting");
  }, [frameSrc, setBridgeStatus]);

  const width = VIEWPORTS[viewport].width;

  return (
    <div className="relative flex h-full min-h-0 w-full items-stretch justify-center overflow-auto bg-[#07080C]">
      <div
        className="relative h-full shrink-0 border-white/10 bg-white"
        style={{ width }}
      >
        <iframe
          key={frameSrc}
          ref={frameRef}
          src={frameSrc}
          title={`GN-Apex live preview — ${pageKey}`}
          className="block h-full w-full border-0 bg-white"
          sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
        />
        <SelectionOverlay />
        <FloatingToolbar />
        <ZoomControls />
      </div>

      {bridgeStatus === "connecting" ? (
        <div className="absolute bottom-4 left-1/2 z-10 flex -translate-x-1/2 items-center gap-2 rounded-full border border-[#00D4FF]/30 bg-[#090A0F]/90 px-3 py-1.5 text-[11px] font-mono uppercase tracking-wider text-[#00D4FF]">
          <Loader2 className="size-3 animate-spin" />
          Connecting live bridge
        </div>
      ) : null}

      {bridgeStatus === "unavailable" ? (
        <div className="absolute bottom-4 left-1/2 z-10 flex max-w-md -translate-x-1/2 items-center gap-2 rounded-full border border-amber-400/30 bg-[#090A0F]/90 px-3 py-1.5 text-[11px] font-mono uppercase tracking-wider text-amber-300">
          <PlugZap className="size-3 shrink-0" />
          Preview runtime offline — verify backend service is running
        </div>
      ) : null}

      {bridgeStatus === "active" ? (
        <div className="pointer-events-none absolute bottom-4 left-1/2 z-10 flex -translate-x-1/2 items-center gap-2 rounded-full border border-white/10 bg-[#090A0F]/90 px-3 py-1.5 text-[11px] font-mono uppercase tracking-wider text-gray-400">
          <MousePointerClick className="size-3 text-[#00D4FF]" />
          Direct Canvas Interaction Enabled
        </div>
      ) : null}
    </div>
  );
}
