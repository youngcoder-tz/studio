// studio/src/components/gnapex-studio/canvas/state-simulator-bar.tsx
'use client';

import React from 'react';
import { FlaskConical, Check, AlertCircle, Loader2, ShieldAlert, Inbox } from 'lucide-react';
import { store, type SimulationState } from '@/lib/gnapex-studio/store';

const STATES: { id: SimulationState; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: 'normal', label: 'Default', icon: Check },
  { id: 'loading', label: 'Loading', icon: Loader2 },
  { id: 'empty', label: 'Empty State', icon: Inbox },
  { id: 'validation_error', label: 'Validation Error', icon: AlertCircle },
  { id: 'auth_error', label: 'Auth Error', icon: ShieldAlert },
];

export function StateSimulatorBar() {
  const simulationState = store((s) => s.simulationState);
  const setSimulationState = store((s) => s.setSimulationState);

  return (
    <div className="flex items-center gap-1 rounded-xl border border-white/10 bg-[#0B0D14]/90 p-1 shadow-2xl backdrop-blur-md">
      <div className="flex items-center gap-1.5 px-2 text-[10px] font-mono uppercase tracking-wider text-gray-500 border-r border-white/10 mr-1">
        <FlaskConical className="size-3.5 text-[#00D4FF]" />
        <span>Simulate Site-User State</span>
      </div>
      {STATES.map((st) => {
        const Icon = st.icon;
        const isActive = simulationState === st.id;
        return (
          <button
            key={st.id}
            type="button"
            onClick={() => setSimulationState(st.id)}
            className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1 text-[11px] font-medium transition-all ${
              isActive
                ? 'bg-[#00D4FF]/20 text-[#00D4FF] border border-[#00D4FF]/30'
                : 'text-gray-400 hover:bg-white/5 hover:text-gray-200'
            }`}
          >
            <Icon className={`size-3 ${st.id === 'loading' && isActive ? 'animate-spin' : ''}`} />
            <span>{st.label}</span>
          </button>
        );
      })}
    </div>
  );
}
