// studio/src/components/gnapex-studio/canvas/directory-overview-stage.tsx
'use client';

import React from 'react';
import {
  Folder,
  FileCode2,
  ChevronRight,
  Lock,
  CheckCircle2,
  CircleDashed,
  ArrowRight,
} from 'lucide-react';
import type { VRFSNode, VRFSRoot } from '@/lib/gnapex-studio/vrfs-engine';
import { store } from '@/lib/gnapex-studio/store';

export function DirectoryOverviewStage({ vrfs }: { vrfs: VRFSRoot }) {
  const activeDirectoryId = store((s) => s.activeDirectoryId);
  const navigateToDirectory = store((s) => s.navigateToDirectory);
  const openPageCanvas = store((s) => s.openPageCanvas);

  const currentNode = activeDirectoryId ? vrfs.nodeMap.get(activeDirectoryId) : null;
  const displayNodes = currentNode ? currentNode.children : vrfs.tree;

  const directories = displayNodes.filter((n) => n.type === 'directory' || n.type === 'param');
  const pages = displayNodes.filter((n) => n.type === 'page');

  return (
    <div className="flex h-full w-full flex-col overflow-y-auto bg-gradient-to-b from-[#090A0F] to-[#07080C] p-8 [scrollbar-width:thin]">
      <header className="mb-8 flex flex-col gap-2">
        <nav aria-label="Directory Breadcrumbs" className="flex items-center gap-2 text-xs font-mono text-gray-500">
          <button type="button" onClick={() => navigateToDirectory(null)} className="hover:text-[#00D4FF] transition-colors">
            {vrfs.workspaceMode} · Site-User Routes
          </button>
          {activeDirectoryId && (
            <>
              <ChevronRight className="size-3 text-gray-700" />
              <span className="text-gray-200">{currentNode?.label || activeDirectoryId}</span>
            </>
          )}
        </nav>
        <div className="flex items-baseline justify-between border-b border-white/10 pb-4">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-white">
              {currentNode ? currentNode.label : 'Site-User Directory Matrix'}
            </h1>
            <p className="mt-1 text-xs text-gray-400">
              {currentNode
                ? `Route group: /portal/${currentNode.id}`
                : 'Explore public, auth and role-based site-user surfaces. No admin/back-office pages.'}
            </p>
          </div>
          <div className="flex items-center gap-3 font-mono text-xs text-gray-500">
            <span>{directories.length} folders</span>
            <span>·</span>
            <span>{pages.length} pages</span>
          </div>
        </div>
      </header>

      {directories.length > 0 && (
        <section className="mb-10">
          <h2 className="mb-4 font-mono text-[11px] font-semibold uppercase tracking-wider text-gray-500">Sub-directories & Dynamic Segments</h2>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {directories.map((dir) => (
              <div
                key={dir.id}
                role="button"
                tabIndex={0}
                onClick={() => navigateToDirectory(dir.id)}
                className="group relative flex flex-col justify-between overflow-hidden rounded-2xl border border-white/10 bg-white/[0.02] p-5 backdrop-blur-md transition-all hover:border-[#00D4FF]/40 hover:bg-[#00D4FF]/[0.03] hover:shadow-[0_20px_40px_-15px_rgba(0,212,255,0.15)] cursor-pointer"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <div className="flex size-10 items-center justify-center rounded-xl bg-[#00D4FF]/10 text-[#00D4FF]">
                      <Folder className="size-5" />
                    </div>
                    {dir.isDynamic && (
                      <span className="rounded-md border border-[#00D4FF]/30 bg-[#00D4FF]/10 px-2 py-0.5 font-mono text-[9px] uppercase tracking-wider text-[#00D4FF]">
                        Parametric
                      </span>
                    )}
                  </div>
                  <h3 className="mt-4 text-base font-semibold text-white group-hover:text-[#00D4FF] transition-colors">{dir.label}</h3>
                  <p className="mt-1 font-mono text-[11px] text-gray-500">/{dir.slug}</p>
                </div>
                <div className="mt-6 flex items-center justify-between border-t border-white/5 pt-3 text-xs text-gray-500">
                  <span>{dir.children.length} items inside</span>
                  <ArrowRight className="size-3.5 text-gray-600 group-hover:translate-x-1 group-hover:text-[#00D4FF] transition-all" />
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {pages.length > 0 && (
        <section>
          <h2 className="mb-4 font-mono text-[11px] font-semibold uppercase tracking-wider text-gray-500">Site-User Pages</h2>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {pages.map((page) => (
              <div
                key={page.id}
                role="button"
                tabIndex={0}
                onClick={() => openPageCanvas(page.id)}
                className="group relative flex flex-col justify-between overflow-hidden rounded-2xl border border-white/10 bg-white/[0.02] p-5 backdrop-blur-md transition-all hover:border-[#00D4FF]/50 hover:bg-[#00D4FF]/[0.04] hover:shadow-[0_20px_40px_-15px_rgba(0,212,255,0.2)] cursor-pointer"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <div className="flex size-10 items-center justify-center rounded-xl bg-white/5 text-gray-300 group-hover:bg-[#00D4FF]/20 group-hover:text-[#00D4FF] transition-colors">
                      <FileCode2 className="size-5" />
                    </div>
                    {page.required ? (
                      <span className="flex items-center gap-1 rounded-full border border-amber-500/30 bg-amber-500/10 px-2 py-0.5 text-[9px] font-semibold text-amber-300">
                        <Lock className="size-2.5" /> Required
                      </span>
                    ) : page.provisioned ? (
                      <span className="flex items-center gap-1 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2 py-0.5 text-[9px] font-semibold text-emerald-400">
                        <CheckCircle2 className="size-2.5" /> Provisioned
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 rounded-full border border-white/10 px-2 py-0.5 text-[9px] text-gray-500">
                        <CircleDashed className="size-2.5" /> Draft
                      </span>
                    )}
                  </div>
                  <h3 className="mt-4 text-base font-semibold text-white group-hover:text-[#00D4FF] transition-colors">{page.label}</h3>
                  <p className="mt-1 font-mono text-[11px] text-gray-500">{page.routePath}</p>
                </div>
                <div className="mt-6 flex items-center justify-between border-t border-white/5 pt-3 text-xs text-gray-400">
                  <span className="font-mono text-[10px]">{page.componentCount} components</span>
                  <span className="flex items-center gap-1 font-semibold text-[#00D4FF] opacity-0 group-hover:opacity-100 transition-opacity">
                    Customize <ArrowRight className="size-3" />
                  </span>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
