// studio/src/components/gnapex-studio/shell/directory-tree.tsx
'use client';

import React, { useState } from 'react';
import {
  Folder,
  FolderOpen,
  FileCode2,
  ChevronRight,
  ChevronDown,
  Lock,
} from 'lucide-react';
import type { VRFSNode } from '@/lib/gnapex-studio/vrfs-engine';
import { store } from '@/lib/gnapex-studio/store';

export function DirectoryTree({ rootNodes }: { rootNodes: VRFSNode[] }) {
  const stageMode = store((s) => s.stageMode);
  const activeDirectoryId = store((s) => s.activeDirectoryId);
  const selection = store((s) => s.selection);
  const navigateToDirectory = store((s) => s.navigateToDirectory);
  const openPageCanvas = store((s) => s.openPageCanvas);

  return (
    <div className="flex h-full flex-col overflow-hidden bg-[#090A0F]">
      <div className="flex items-center justify-between border-b border-white/5 px-4 py-3">
        <div className="flex items-center gap-2">
          <Folder className="size-4 text-[#00D4FF]" />
          <span className="text-[12px] font-semibold uppercase tracking-wider text-gray-200">Site-User Routes</span>
        </div>
        <button
          type="button"
          onClick={() => navigateToDirectory(null)}
          className={`rounded px-2 py-0.5 font-mono text-[10px] uppercase transition-colors ${
            stageMode === 'DIRECTORY_OVERVIEW' && activeDirectoryId === null
              ? 'bg-[#00D4FF]/20 text-[#00D4FF]'
              : 'text-gray-500 hover:text-gray-300'
          }`}
        >
          Root
        </button>
      </div>
      <div className="flex-1 overflow-y-auto px-2 py-2 [scrollbar-width:thin]">
        <ul className="space-y-0.5">
          {rootNodes.map((node) => (
            <TreeNodeItem
              key={node.id}
              node={node}
              depth={0}
              onOpenPage={openPageCanvas}
              onNavigateDir={navigateToDirectory}
              currentActivePage={(selection as any).pageKey}
              currentActiveDir={activeDirectoryId}
            />
          ))}
        </ul>
      </div>
    </div>
  );
}

function TreeNodeItem({
  node,
  depth,
  onOpenPage,
  onNavigateDir,
  currentActivePage,
  currentActiveDir,
}: {
  node: VRFSNode;
  depth: number;
  onOpenPage: (pageKey: string) => void;
  onNavigateDir: (dirId: string | null) => void;
  currentActivePage: string | null;
  currentActiveDir: string | null;
}) {
  const [isOpen, setIsOpen] = useState(true);
  const isDirectory = node.type === 'directory' || node.type === 'param';
  const isSelected = isDirectory ? currentActiveDir === node.id : currentActivePage === node.id;

  const handleAction = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isDirectory) {
      setIsOpen(!isOpen);
      onNavigateDir(node.id);
    } else {
      onOpenPage(node.id);
    }
  };

  return (
    <li>
      <div
        role="button"
        tabIndex={0}
        onClick={handleAction}
        style={{ paddingLeft: `${depth * 14 + 8}px` }}
        className={`group flex items-center justify-between rounded-lg py-1.5 pr-2 transition-all cursor-pointer ${
          isSelected ? 'bg-[#00D4FF]/10 text-[#00D4FF]' : 'text-gray-400 hover:bg-white/[0.04] hover:text-gray-200'
        }`}
      >
        <div className="flex min-w-0 items-center gap-2">
          {isDirectory ? (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setIsOpen(!isOpen);
              }}
              className="text-gray-600 hover:text-gray-400"
            >
              {isOpen ? <ChevronDown className="size-3" /> : <ChevronRight className="size-3" />}
            </button>
          ) : (
            <span className="w-3" />
          )}
          {isDirectory ? (
            isOpen ? <FolderOpen className="size-3.5 shrink-0 text-[#00D4FF]/80" /> : <Folder className="size-3.5 shrink-0 text-gray-500 group-hover:text-gray-400" />
          ) : (
            <FileCode2 className={`size-3.5 shrink-0 ${isSelected ? 'text-[#00D4FF]' : 'text-gray-500'}`} />
          )}
          <span className="truncate font-mono text-[12px]">{node.slug}</span>
        </div>
        <div className="flex items-center gap-1.5">
          {node.required && <Lock className="size-2.5 text-amber-400/80" />}
          {node.type === 'page' && node.componentCount > 0 && (
            <span className="rounded-full bg-white/5 px-1.5 py-0.2 font-mono text-[9px] text-gray-500">{node.componentCount}</span>
          )}
        </div>
      </div>
      {isDirectory && isOpen && node.children.length > 0 && (
        <ul className="space-y-0.5">
          {node.children.map((child) => (
            <TreeNodeItem
              key={child.id}
              node={child}
              depth={depth + 1}
              onOpenPage={onOpenPage}
              onNavigateDir={onNavigateDir}
              currentActivePage={currentActivePage}
              currentActiveDir={currentActiveDir}
            />
          ))}
        </ul>
      )}
    </li>
  );
}
