// studio/src/components/gnapex-studio/shell/activity-icon-rail.tsx
'use client';

import React from 'react';
import {
  FolderTree,
  Settings2,
  Palette,
  Boxes,
  FlaskConical,
  Sparkles,
  Image as ImageIcon,
  History,
  Sliders,
} from 'lucide-react';
import { store, type ActiveStation } from '@/lib/gnapex-studio/store';

interface StationButton {
  id: ActiveStation;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  highlight?: boolean;
}

const STATIONS: StationButton[] = [
  { id: 'explorer', label: 'Pages & Directories', icon: FolderTree },
  { id: 'setups', label: 'Workspace Setup & Provisioning', icon: Settings2 },
  { id: 'palette', label: 'Design System & Tokens', icon: Palette },
  { id: 'library', label: 'Component & Zone Catalog', icon: Boxes },
  { id: 'states', label: 'Site-User State Simulator', icon: FlaskConical },
  { id: 'gora', label: 'Gora AI Design Copilot', icon: Sparkles, highlight: true },
  { id: 'assets', label: 'Media Warehouse', icon: ImageIcon },
  { id: 'revisions', label: 'Releases & Revision Ledger', icon: History },
  { id: 'settings', label: 'Studio Engine Preferences', icon: Sliders },
];

export function ActivityIconRail() {
  const activeStation = store((s) => s.activeStation);
  const setActiveStation = store((s) => s.setActiveStation);

  return (
    <aside
      aria-label="Studio Activity Rail"
      className="flex w-16 shrink-0 flex-col items-center justify-between border-l border-white/10 bg-[#07080C] py-3.5 z-40 select-none"
    >
      <div className="flex w-full flex-col items-center gap-1.5">
        {STATIONS.map((station) => {
          const Icon = station.icon;
          const isActive = activeStation === station.id;

          return (
            <button
              key={station.id}
              type="button"
              onClick={() => setActiveStation(station.id)}
              title={station.label}
              className={`group relative flex size-10 items-center justify-center rounded-xl transition-all ${
                isActive
                  ? 'bg-[#00D4FF]/15 text-[#00D4FF] shadow-[0_0_20px_rgba(0,212,255,0.25)]'
                  : station.highlight
                  ? 'text-fuchsia-400 hover:bg-fuchsia-500/10'
                  : 'text-gray-400 hover:bg-white/[0.05] hover:text-gray-200'
              }`}
            >
              <Icon className="size-[18px] transition-transform duration-200 group-hover:scale-110" />
              {isActive && (
                <span className="absolute -left-1 top-2 bottom-2 w-0.5 rounded-r bg-[#00D4FF]" />
              )}
              <div className="pointer-events-none absolute right-14 z-50 hidden whitespace-nowrap rounded-lg border border-white/10 bg-[#0B0D14] px-2.5 py-1 text-[11px] font-medium text-gray-200 shadow-2xl backdrop-blur-md group-hover:block">
                {station.label}
              </div>
            </button>
          );
        })}
      </div>
      <div className="flex flex-col items-center gap-2">
        <span className="text-[9px] font-mono tracking-tighter text-gray-600">GN-APEX</span>
      </div>
    </aside>
  );
}
