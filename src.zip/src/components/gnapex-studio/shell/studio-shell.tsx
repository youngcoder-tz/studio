// studio/src/components/gnapex-studio/shell/studio-shell.tsx
// GN-Apex Workspace Studio Shell — Site-User Directory Navigation

'use client';

import { useMemo } from 'react';
import { store } from '@/lib/gnapex-studio/store';
import { useAutosave } from '@/hooks/gnapex-studio/use-autosave';
import { buildVRFS } from '@/lib/gnapex-studio/vrfs-engine';

import { TopBar } from './top-bar';
import { DirectoryTree } from './directory-tree';
import { DirectoryOverviewStage } from '../canvas/directory-overview-stage';
import { PreviewFrame } from '@/components/gnapex-studio/canvas/preview-frame';
import { StateSimulatorBar } from '../canvas/state-simulator-bar';
import { InspectorRoot } from '@/components/gnapex-studio/inspector/inspector-root';
import { StatusBar } from './status-bar';
import { CommandPalette } from '@/components/gnapex-studio/command-palette/command-palette';
import { ShortcutsModal } from '@/components/gnapex-studio/overlays/shortcuts-modal';
import { CanvasContextMenu } from '@/components/gnapex-studio/context-menu/context-menu';
import { ActivityIconRail } from './activity-icon-rail';
import { DesignSystemPanel } from '../design-system/design-system-panel';
import { AssetsPanel } from '../panels/assets-panel';
import { HistoryPanel } from '../panels/history-panel';

export function StudioShell({
  projectId,
  manifest,
  document,
  previewToken,
  previewOrigin,
  framedPageKey,
}: {
  projectId: string;
  manifest: any;
  document: any;
  previewToken: string | null;
  previewOrigin: string;
  framedPageKey: string;
}) {
  const stageMode = store((s) => s.stageMode);
  const activeStation = store((s) => s.activeStation);
  useAutosave(projectId, !!document);

  const vrfs = useMemo(() => buildVRFS(manifest, document), [manifest, document]);

  return (
    <div className="flex h-dvh flex-col bg-[#090A0F] text-gray-100 overflow-hidden select-none">
      <TopBar manifest={manifest} />
      <div className="flex min-h-0 flex-1">
        <aside className="w-72 shrink-0 border-r border-white/5 bg-[#0B0D14]">
          <DirectoryTree rootNodes={vrfs.tree} />
        </aside>

        <main className="relative flex min-w-0 flex-1 flex-col overflow-hidden bg-[#07080C]" data-gnapex-canvas>
          {stageMode === 'DIRECTORY_OVERVIEW' ? (
            <DirectoryOverviewStage vrfs={vrfs} />
          ) : (
            <>
              <div className="absolute top-4 left-1/2 z-30 -translate-x-1/2">
                <StateSimulatorBar />
              </div>
              <PreviewFrame
                projectId={projectId}
                pageKey={framedPageKey}
                previewToken={previewToken}
                resolvedOrigin={previewOrigin}
              />
            </>
          )}
        </main>

        <aside className="w-80 shrink-0 border-l border-white/5 bg-[#0B0D14] overflow-y-auto">
          {activeStation === 'explorer' && <InspectorRoot />}
          {activeStation === 'palette' && (
            <div className="p-4">
              <DesignSystemPanel />
            </div>
          )}
          {activeStation === 'assets' && <AssetsPanel />}
          {activeStation === 'revisions' && <HistoryPanel />}
          {activeStation !== 'explorer' && activeStation !== 'palette' && activeStation !== 'assets' && activeStation !== 'revisions' && <InspectorRoot />}
        </aside>

        <ActivityIconRail />
      </div>

      <StatusBar />
      <CommandPalette open={false} onOpenChange={() => {}} />
      <ShortcutsModal open={false} onClose={() => {}} />
    </div>
  );
}
