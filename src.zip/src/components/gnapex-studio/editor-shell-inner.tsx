// studio/src/components/gnapex-studio/editor-shell-inner.tsx
//
// THE EDITOR BOOT ROOT.
//
// Dynamically resolves preview paths, tokens, and CDN origin directly from the
// backend workspace response. No static NEXT_PUBLIC_PORTAL_ORIGIN needed.

"use client";

import { useEffect, useMemo } from "react";
import Link from "next/link";
import { DoorOpen, Loader2 } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Toaster } from "sonner";

import { useManifest, useWorkspaceDocument } from "@/lib/api/hooks";
import { mintPreviewToken } from "@/lib/api/workspace";
import { store } from "@/lib/gnapex-studio/store";
import { resolveInitialPageKey } from "@/lib/gnapex-studio/visual-ir";
import { useAutosave } from "@/hooks/gnapex-studio/use-autosave";
import { StudioShell } from "@/components/gnapex-studio/shell/studio-shell";

export default function EditorShellInner({ projectId }: { projectId: string }) {
  const manifestQuery = useManifest(projectId);
  const documentQuery = useWorkspaceDocument(projectId, true);
  const selectionPageKey = store((s) => s.selection?.pageKey);
  const hasTemplate = !!documentQuery.data?.templateId;

  useAutosave(projectId, hasTemplate);

  const initialPageKey = useMemo(() => {
    if (!manifestQuery.data) return null;
    if (!documentQuery.data) return manifestQuery.data.defaultPageKey ?? null;
    try {
      return resolveInitialPageKey(manifestQuery.data, documentQuery.data);
    } catch {
      return manifestQuery.data.defaultPageKey ?? null;
    }
  }, [documentQuery.data, manifestQuery.data]);

  // Fetches signed preview session token directly from backend
  const tokenQuery = useQuery({
    queryKey: ["gnapex-preview-token", projectId],
    queryFn: async () => {
      const res = await mintPreviewToken(projectId);
      if (!res?.ok || !res?.token) {
        throw new Error(res?.reason || "Could not mint preview token.");
      }
      return {
        token: res.token as string,
        previewPath: res.previewPath ?? null,
      };
    },
    enabled: hasTemplate,
    retry: false,
    staleTime: 1000 * 60 * 10, // 10 minutes cache
  });

  useEffect(() => {
    if (manifestQuery.data && projectId) {
      try {
        store.getState().setMeta({
          projectId,
          projectName: manifestQuery.data.projectName,
          workspaceMode: manifestQuery.data.workspaceMode,
        });
      } catch {}
    }
  }, [manifestQuery.data, projectId]);

  useEffect(() => {
    if (documentQuery.data) {
      try {
        store.getState().hydrateDocument(documentQuery.data);
      } catch {}
    }
  }, [documentQuery.data]);

  useEffect(() => {
    if (!initialPageKey) return;
    try {
      const sel = store.getState().selection;
      if (!sel?.pageKey) {
        store.getState().selectPage(initialPageKey);
      }
    } catch {}
  }, [initialPageKey]);

  const isPending = manifestQuery.isPending || documentQuery.isPending;
  const isError = manifestQuery.isError || !manifestQuery.data;
  const notCommissioned = !isPending && !isError && !hasTemplate;

  if (isPending) {
    return (
      <div className="flex h-dvh flex-col items-center justify-center gap-3 bg-[#090A0F] text-gray-400">
        <Loader2 className="size-6 animate-spin text-[#00D4FF]" />
        <p className="text-[11px] font-mono uppercase tracking-widest">
          Resolving workspace contract & ERP runtime…
        </p>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="flex h-dvh flex-col items-center justify-center gap-3 bg-[#090A0F]">
        <span className="text-[13px] text-red-400">
          The workspace contract could not be loaded. Check your permissions.
        </span>
        <p className="text-[11px] font-mono uppercase tracking-widest text-gray-600">
          GN-Apex Studio
        </p>
      </div>
    );
  }

  if (notCommissioned) {
    return (
      <div className="flex h-dvh flex-col items-center justify-center gap-4 bg-[#090A0F] text-gray-300">
        <DoorOpen className="size-8 text-[#00D4FF]" />
        <p className="text-[14px] font-semibold">
          This workspace has not been commissioned yet
        </p>
        <p className="max-w-sm text-center text-[12px] leading-relaxed text-gray-500">
          The Studio customizes a provisioned operational workspace. Run the
          setup wizard to choose an initial template.
        </p>
        <Link
          href={`/studio/${projectId}/setup`}
          className="rounded-lg bg-[#00D4FF] px-4 py-2 text-[13px] font-semibold text-[#090A0F] hover:opacity-90"
        >
          Open Setup Wizard
        </Link>
        <Toaster position="bottom-right" />
      </div>
    );
  }

  // 🌟 DYNAMIC RESOLUTION:
  // If the backend template provides an explicit CDN bundleUrl, extract its origin,
  // else fall back to the browser window origin (for same-domain or local dev).
  const bundleUrl = documentQuery.data?.templateRuntime?.bundleUrl;
  let dynamicOrigin = "";
  if (bundleUrl && bundleUrl.startsWith("http")) {
    try {
      dynamicOrigin = new URL(bundleUrl).origin;
    } catch {
      dynamicOrigin =
        typeof window !== "undefined" ? window.location.origin : "";
    }
  } else {
    dynamicOrigin = typeof window !== "undefined" ? window.location.origin : "";
  }

  const framedPageKey = selectionPageKey ?? initialPageKey ?? "auth-login";

  return (
    <>
      <StudioShell
        projectId={projectId}
        manifest={manifestQuery.data}
        document={documentQuery.data}
        previewToken={tokenQuery.data?.token ?? null}
        previewOrigin={dynamicOrigin}
        framedPageKey={framedPageKey}
      />
      <Toaster position="bottom-right" />
    </>
  );
}
